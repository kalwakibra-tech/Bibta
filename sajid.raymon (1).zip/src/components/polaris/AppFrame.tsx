import React, { useState } from 'react';
import { ScreenName } from '../Navbar.tsx';
import { TopBar } from './TopBar.tsx';
import { Sidebar } from './Sidebar.tsx';
import { GlobalSearchModal } from './GlobalSearchModal.tsx';
import { OfflineIndicator } from '../OfflineIndicator.tsx';

interface AppFrameProps {
  currentScreen: ScreenName;
  onNavigate: (screen: ScreenName, params?: any) => void;
  children: React.ReactNode;
}

export const AppFrame: React.FC<AppFrameProps> = ({
  currentScreen,
  onNavigate,
  children,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#1A1A1A] flex flex-col font-sans selection:bg-[#303030] selection:text-white">
      {/* Layer 0: Chrome TopBar (56px, #1A1A1A) */}
      <TopBar
        onNavigate={onNavigate}
        onOpenSearch={() => setSearchModalOpen(true)}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
      />

      {/* Layer 1 & 2: Rail & Canvas with 12px Top-Left Radius */}
      <div className="flex-1 flex bg-[#F1F1F1] rounded-tl-xl overflow-hidden min-h-0">
        {/* Layer 1: Rail Sidebar (240px, #EBEBEB) */}
        <Sidebar
          currentScreen={currentScreen}
          onNavigate={onNavigate}
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
        />

        {/* Layer 2: Main Canvas (#F1F1F1) */}
        <main className="flex-1 overflow-y-auto min-w-0 bg-[#F1F1F1]">
          {children}
        </main>
      </div>

      {/* Polaris Global Search Modal (⌘K) */}
      <GlobalSearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onNavigate={onNavigate}
      />

      {/* Offline Status Pill */}
      <OfflineIndicator />
    </div>
  );
};
