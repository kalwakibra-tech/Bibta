import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall.ts';
import { Download, Smartphone, X, CheckCircle2 } from 'lucide-react';

interface PWAInstallButtonProps {
  variant?: 'navbar' | 'full' | 'settings';
  className?: string;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  variant = 'navbar',
  className = '',
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [showDesktopGuide, setShowDesktopGuide] = useState(false);

  // If already running in standalone mode (already installed), show badge or null
  if (isInstalled) {
    if (variant === 'settings') {
      return (
        <div className="flex items-center space-x-2 text-xs font-semibold text-emerald-700 bg-emerald-50 px-3 py-2 rounded-lg border border-emerald-200">
          <CheckCircle2 className="w-4 h-4" />
          <span>App is currently running as an installed PWA.</span>
        </div>
      );
    }
    return null;
  }

  // Handle click depending on platform
  const handleClick = async () => {
    if (isInstallable) {
      await install();
    } else if (isIOS) {
      setShowIOSGuide(true);
    } else {
      setShowDesktopGuide(true);
    }
  };

  const buttonContent = (
    <>
      <Download className="w-3.5 h-3.5 shrink-0" />
      <span>Install App</span>
    </>
  );

  return (
    <>
      {variant === 'navbar' && (
        <button
          onClick={handleClick}
          title="Install Tailor Shop Manager on this device"
          className={`inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 shadow-2xs transition-colors ${className}`}
        >
          {buttonContent}
        </button>
      )}

      {variant === 'full' && (
        <button
          onClick={handleClick}
          className={`w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold flex items-center justify-center space-x-2 shadow-xs transition-colors ${className}`}
        >
          <Smartphone className="w-4 h-4" />
          <span>Install Tailor Shop App</span>
        </button>
      )}

      {variant === 'settings' && (
        <button
          onClick={handleClick}
          className={`px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold inline-flex items-center space-x-1.5 shadow-2xs ${className}`}
        >
          {buttonContent}
        </button>
      )}

      {/* iOS Safari Guide Modal */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-sm rounded-xl bg-white p-6 shadow-xl border border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-bold text-gray-900">Install on iPhone / iPad</h3>
              <button onClick={() => setShowIOSGuide(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-gray-600 space-y-2 leading-relaxed">
              <span>Apple Safari does not show an automatic prompt. To install:</span>
              <br /><br />
              <strong>1.</strong> Tap the <strong>Share</strong> icon (box with upward arrow) in the Safari toolbar.<br />
              <strong>2.</strong> Scroll down and tap <strong>Add to Home Screen</strong>.<br />
              <strong>3.</strong> Tap <strong>Add</strong> at top right.
            </p>
            <button
              onClick={() => setShowIOSGuide(false)}
              className="mt-5 w-full rounded-lg bg-gray-100 py-2 text-xs font-semibold text-gray-800 hover:bg-gray-200"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Desktop / Non-Prompt Browser Guide Modal */}
      {showDesktopGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-sm rounded-xl bg-white p-6 shadow-xl border border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-bold text-gray-900">Install Web App</h3>
              <button onClick={() => setShowDesktopGuide(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-gray-600 leading-relaxed space-y-2">
              <span>This web application is fully PWA-enabled and ready to install.</span>
              <br /><br />
              • On <strong>Google Chrome / Edge</strong>: Click the <strong>Install</strong> icon in the right side of the address bar.<br />
              • On <strong>Android Chrome</strong>: Tap the menu (three dots) &gt; <strong>Install app</strong> or <strong>Add to Home screen</strong>.
            </p>
            <button
              onClick={() => setShowDesktopGuide(false)}
              className="mt-5 w-full rounded-lg bg-blue-600 py-2 text-xs font-semibold text-white hover:bg-blue-700"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </>
  );
};
