import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { OfficerOrder } from '../types/index.ts';
import { StatusBadge } from './StatusBadge.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { PolarisBadge } from './polaris/PolarisBadge.tsx';
import {
  formatDate,
  formatMonth,
  getPeriodRange,
} from '../utils/logic.ts';
import {
  TrendingUp,
  CreditCard,
  Clock,
  Scissors,
  ArrowRight,
  X,
  PieChart,
  Plane,
  AlertCircle,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface DashboardScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

type DashboardPeriod = 'Today' | 'This Week' | 'This Month' | 'All Time' | 'Pick Month';
type ChartMetric = 'Orders' | 'Sales' | 'Collection' | 'Due';

export const DashboardScreen: React.FC<DashboardScreenProps> = ({ onNavigate }) => {
  const { state } = useApp();

  const [period, setPeriod] = useState<DashboardPeriod>('This Month');
  const [customMonth, setCustomMonth] = useState(formatMonth());
  const [chartMetric, setChartMetric] = useState<ChartMetric>('Sales');
  const [selectedRunningYear, setSelectedRunningYear] = useState<string>(
    state.settings.runningYears[0] || '2026–2027'
  );

  // Detail Drawer State
  const [activeDetailDrawer, setActiveDetailDrawer] = useState<
    'orders' | 'sales' | 'collection' | 'due' | 'overdue' | null
  >(null);

  const todayStr = formatDate();

  // Date range for period
  const dateRange = useMemo(() => {
    return getPeriodRange(period, customMonth);
  }, [period, customMonth]);

  // Filtered active Officer Orders in period (deleted orders excluded)
  const ordersInPeriod = useMemo(() => {
    if (!dateRange) return state.officerOrders;
    return state.officerOrders.filter(
      (o) => o.orderDate >= dateRange.start && o.orderDate <= dateRange.end
    );
  }, [state.officerOrders, dateRange]);

  // Sales in period (Officer order totals after discount)
  const salesInPeriod = useMemo(() => {
    return ordersInPeriod.reduce((sum, o) => {
      const net = (Number(o.totalAmount) || 0) - (Number(o.discountAmount) || 0);
      return sum + net;
    }, 0);
  }, [ordersInPeriod]);

  // Collection in period (advances + payments)
  const collectionsInPeriod = useMemo(() => {
    const advances = state.officerOrders
      .filter((o) => {
        if (!dateRange) return (o.advance || 0) > 0;
        return o.orderDate >= dateRange.start && o.orderDate <= dateRange.end && (o.advance || 0) > 0;
      })
      .map((o) => ({
        type: 'Advance',
        orderNumber: o.orderNumber,
        customerName: o.customerName,
        amount: o.advance,
        date: o.orderDate,
      }));

    const pays: any[] = [];
    for (const o of state.officerOrders) {
      for (const p of o.payments || []) {
        if (!dateRange || (p.date >= dateRange.start && p.date <= dateRange.end)) {
          pays.push({
            type: 'Payment',
            orderNumber: o.orderNumber,
            customerName: o.customerName,
            amount: p.amount,
            date: p.date,
          });
        }
      }
    }

    const all = [...advances, ...pays].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );

    const total = all.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
    return { list: all, total };
  }, [state.officerOrders, dateRange]);

  // Customer Due at present (all active orders with due > 0)
  const customerDueAtPresent = useMemo(() => {
    const ordersWithDue = state.officerOrders.filter((o) => (o.due || 0) > 0);
    const total = ordersWithDue.reduce((sum, o) => sum + (o.due || 0), 0);
    return { list: ordersWithDue, total };
  }, [state.officerOrders]);

  // Overdue Deliveries
  const overdueOrders = useMemo(() => {
    return state.officerOrders.filter((o) => {
      if (o.status === 'Delivered') return false;
      if (!o.deliveryDate) return false;
      return o.deliveryDate < todayStr;
    });
  }, [state.officerOrders, todayStr]);

  // Branch split for Officer orders
  const branchStats = useMemo(() => {
    const counts: Record<string, { count: number; total: number }> = {
      GDP: { count: 0, total: 0 },
      'NON-GDP': { count: 0, total: 0 },
      'HALF WING': { count: 0, total: 0 },
    };

    let otherCount = 0;
    let otherTotal = 0;

    ordersInPeriod.forEach((o) => {
      const b = (o.branch || '').trim();
      const amount = o.totalAmount || 0;
      if (b === 'GDP' || b === 'NON-GDP' || b === 'HALF WING') {
        counts[b].count += 1;
        counts[b].total += amount;
      } else {
        otherCount += 1;
        otherTotal += amount;
      }
    });

    const totalOrders = ordersInPeriod.length || 1;

    return [
      {
        branch: 'GDP',
        count: counts['GDP'].count,
        total: counts['GDP'].total,
        percentage: Math.round((counts['GDP'].count / totalOrders) * 100),
      },
      {
        branch: 'NON-GDP',
        count: counts['NON-GDP'].count,
        total: counts['NON-GDP'].total,
        percentage: Math.round((counts['NON-GDP'].count / totalOrders) * 100),
      },
      {
        branch: 'HALF WING',
        count: counts['HALF WING'].count,
        total: counts['HALF WING'].total,
        percentage: Math.round((counts['HALF WING'].count / totalOrders) * 100),
      },
      ...(otherCount > 0
        ? [
            {
              branch: 'General',
              count: otherCount,
              total: otherTotal,
              percentage: Math.round((otherCount / totalOrders) * 100),
            },
          ]
        : []),
    ];
  }, [ordersInPeriod]);

  // Airman Item Summary for selected Running Year (no money)
  const airmanYearItems = useMemo(() => {
    const yearAirmanOrders = state.airmanOrders.filter(
      (o) => o.runningYear === selectedRunningYear
    );

    const counts: Record<string, number> = {};
    (state.settings.airmanItems || []).forEach((it) => {
      counts[it.name] = 0;
    });

    yearAirmanOrders.forEach((o) => {
      o.items.forEach((it) => {
        counts[it.name] = (counts[it.name] || 0) + (it.quantity || 1);
      });
    });

    return Object.entries(counts).map(([name, qty]) => ({ name, qty }));
  }, [state.airmanOrders, state.settings.airmanItems, selectedRunningYear]);

  // 6-Month Trend Data for selected Metric
  const monthlyMetricTrends = useMemo(() => {
    const result: {
      month: string;
      monthLabel: string;
      Orders: number;
      Sales: number;
      Collection: number;
      Due: number;
    }[] = [];

    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const mStr = formatMonth(d);
      const mLabel = d.toLocaleString('en-US', { month: 'short' });

      // Orders in month
      const mOrders = state.officerOrders.filter((o) => (o.orderDate || '').slice(0, 7) === mStr);
      const ordersCount = mOrders.length;
      const salesTotal = mOrders.reduce(
        (sum, o) => sum + ((o.totalAmount || 0) - (o.discountAmount || 0)),
        0
      );

      // Collections in month
      let colTotal = 0;
      mOrders.forEach((o) => {
        if ((o.advance || 0) > 0) colTotal += o.advance;
      });
      state.officerOrders.forEach((o) => {
        (o.payments || []).forEach((p) => {
          if ((p.date || '').slice(0, 7) === mStr) colTotal += p.amount;
        });
      });

      // Due on orders in month
      const dueTotal = mOrders.reduce((sum, o) => sum + (o.due || 0), 0);

      result.push({
        month: mStr,
        monthLabel: mLabel,
        Orders: ordersCount,
        Sales: salesTotal,
        Collection: colTotal,
        Due: dueTotal,
      });
    }

    return result;
  }, [state.officerOrders]);

  const maxChartValue = useMemo(() => {
    const vals = monthlyMetricTrends.map((t) => t[chartMetric]);
    const max = Math.max(...vals);
    return max > 0 ? max : 1;
  }, [monthlyMetricTrends, chartMetric]);

  return (
    <PolarisPage
      title="Home"
      subtitle="Overview of shop production, cash collection, and deliveries"
      fullWidth={true}
    >
      {/* Period Filter Row */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3 rounded-xl border border-[#E3E3E3] shadow-[0_1px_0_rgba(26,26,26,0.07)]">
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[12px] font-[550] text-[#616161] mr-1">Period:</span>
          {(['Today', 'This Week', 'This Month', 'All Time', 'Pick Month'] as DashboardPeriod[]).map(
            (p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={`h-7 px-3 rounded-lg text-[12px] font-[550] transition-colors ${
                  period === p
                    ? 'bg-[#1A1A1A] text-white shadow-2xs'
                    : 'bg-[#F1F1F1] text-[#303030] hover:bg-[#E3E3E3]'
                }`}
              >
                {p}
              </button>
            )
          )}
          {period === 'Pick Month' && (
            <input
              type="month"
              value={customMonth}
              onChange={(e) => setCustomMonth(e.target.value)}
              className="h-7 px-2.5 text-[12px] bg-white border border-[#E3E3E3] rounded-lg ml-1 font-[550]"
            />
          )}
        </div>

        {dateRange && (
          <div className="text-[12px] text-[#616161] font-medium">
            {dateRange.start} → {dateRange.end}
          </div>
        )}
      </div>

      {/* Polaris 4-Column Metrics Card */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Total Orders */}
        <div
          onClick={() => setActiveDetailDrawer('orders')}
          className="p-4 bg-white rounded-xl border border-[#E3E3E3] shadow-[0_1px_0_rgba(26,26,26,0.07)] hover:border-[#8A8A8A] cursor-pointer transition-all"
        >
          <div className="text-[12px] font-[450] text-[#616161] underline decoration-dotted">
            Orders ({period})
          </div>
          <div className="text-[20px] leading-7 font-[650] text-[#1A1A1A] mt-1 tabular-nums">
            {ordersInPeriod.length}
          </div>
          <div className="text-[11px] text-[#005BD3] font-medium mt-1">Tap for details</div>
        </div>

        {/* Total Sales */}
        <div
          onClick={() => setActiveDetailDrawer('sales')}
          className="p-4 bg-white rounded-xl border border-[#E3E3E3] shadow-[0_1px_0_rgba(26,26,26,0.07)] hover:border-[#8A8A8A] cursor-pointer transition-all"
        >
          <div className="text-[12px] font-[450] text-[#616161] underline decoration-dotted">
            Net Sales ({period})
          </div>
          <div className="text-[20px] leading-7 font-[650] text-[#1A1A1A] mt-1 tabular-nums">
            ৳{salesInPeriod.toLocaleString()}
          </div>
          <div className="text-[11px] text-[#005BD3] font-medium mt-1">Tap for details</div>
        </div>

        {/* Cash Collection */}
        <div
          onClick={() => setActiveDetailDrawer('collection')}
          className="p-4 bg-white rounded-xl border border-[#E3E3E3] shadow-[0_1px_0_rgba(26,26,26,0.07)] hover:border-[#8A8A8A] cursor-pointer transition-all"
        >
          <div className="text-[12px] font-[450] text-[#616161] underline decoration-dotted">
            Collection Received
          </div>
          <div className="text-[20px] leading-7 font-[650] text-[#0C5132] mt-1 tabular-nums">
            ৳{collectionsInPeriod.total.toLocaleString()}
          </div>
          <div className="text-[11px] text-[#005BD3] font-medium mt-1">Tap for details</div>
        </div>

        {/* Customer Due */}
        <div
          onClick={() => setActiveDetailDrawer('due')}
          className="p-4 bg-white rounded-xl border border-[#E3E3E3] shadow-[0_1px_0_rgba(26,26,26,0.07)] hover:border-[#8A8A8A] cursor-pointer transition-all"
        >
          <div className="text-[12px] font-[450] text-[#616161] underline decoration-dotted">
            Current Receivable Due
          </div>
          <div
            className={`text-[20px] leading-7 font-[650] mt-1 tabular-nums ${
              customerDueAtPresent.total > 0 ? 'text-[#8E0B21]' : 'text-[#1A1A1A]'
            }`}
          >
            ৳{customerDueAtPresent.total.toLocaleString()}
          </div>
          <div className="text-[11px] text-[#005BD3] font-medium mt-1">Tap for details</div>
        </div>
      </div>

      {/* Overdue Alert Banner (If Any) */}
      {overdueOrders.length > 0 && (
        <div
          onClick={() => setActiveDetailDrawer('overdue')}
          className="p-3.5 bg-[#FFF4F4] rounded-xl border border-[#FEE9E8] flex items-center justify-between cursor-pointer hover:bg-[#FEE9E8] transition-colors"
        >
          <div className="flex items-center space-x-2.5">
            <AlertCircle className="w-4 h-4 text-[#8E0B21]" />
            <span className="text-[13px] font-[550] text-[#8E0B21]">
              {overdueOrders.length} order{overdueOrders.length > 1 ? 's are' : ' is'} past the promised delivery date.
            </span>
          </div>
          <span className="text-[12px] text-[#8E0B21] font-[650] underline">View Overdue</span>
        </div>
      )}

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Trend Chart with Metric Switch */}
        <div className="lg:col-span-2">
          <PolarisCard
            title={`6-Month Trend (${chartMetric})`}
            actions={
              <div className="flex items-center space-x-1 bg-[#F1F1F1] p-0.5 rounded-lg">
                {(['Orders', 'Sales', 'Collection', 'Due'] as ChartMetric[]).map((m) => (
                  <button
                    key={m}
                    onClick={() => setChartMetric(m)}
                    className={`h-6 px-2.5 rounded-md text-[11px] font-[550] transition-colors ${
                      chartMetric === m
                        ? 'bg-white text-[#1A1A1A] shadow-2xs'
                        : 'text-[#616161] hover:text-[#1A1A1A]'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            }
          >
            <div className="grid grid-cols-6 gap-3 items-end h-40 pt-4 border-b border-[#E3E3E3] pb-2">
              {monthlyMetricTrends.map((t) => {
                const val = t[chartMetric];
                const pct = Math.min(100, Math.round((val / maxChartValue) * 100));

                return (
                  <div key={t.month} className="flex flex-col items-center h-full justify-end group">
                    <span className="text-[10px] text-[#616161] font-bold mb-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      {chartMetric === 'Orders' ? val : `৳${val.toLocaleString()}`}
                    </span>
                    <div
                      style={{ height: `${Math.max(6, pct)}%` }}
                      className="w-full max-w-[36px] bg-[#303030] hover:bg-[#1A1A1A] rounded-t-md transition-all shadow-2xs"
                    />
                    <span className="text-[11px] font-[550] text-[#616161] mt-2">
                      {t.monthLabel}
                    </span>
                  </div>
                );
              })}
            </div>
          </PolarisCard>
        </div>

        {/* Branch Split */}
        <div>
          <PolarisCard title="Branch Split (Officer Orders)">
            <div className="space-y-3 pt-1">
              {branchStats.map((b) => (
                <div key={b.branch} className="space-y-1">
                  <div className="flex justify-between items-center text-[12px]">
                    <span className="font-[650] text-[#1A1A1A]">{b.branch}</span>
                    <span className="text-[#616161]">
                      {b.count} orders ({b.percentage}%)
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-[#EBEBEB] overflow-hidden">
                    <div
                      style={{ width: `${b.percentage}%` }}
                      className="h-full rounded-full bg-[#303030]"
                    />
                  </div>
                </div>
              ))}
            </div>
          </PolarisCard>
        </div>
      </div>

      {/* Airman Uniform Production Block (No Money) */}
      <PolarisCard
        title="Airman Uniform Production"
        subtitle={`Running Year: ${selectedRunningYear}`}
        actions={
          <select
            value={selectedRunningYear}
            onChange={(e) => setSelectedRunningYear(e.target.value)}
            className="h-7 px-2.5 text-[12px] bg-white border border-[#E3E3E3] rounded-lg text-[#303030] font-[550] focus:outline-none focus:border-[#303030] cursor-pointer shadow-2xs"
          >
            {state.settings.runningYears.map((yr) => (
              <option key={yr} value={yr}>
                {yr}
              </option>
            ))}
          </select>
        }
      >
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {airmanYearItems.map((item) => (
            <div
              key={item.name}
              className="p-3 bg-[#F7F7F7] rounded-xl border border-[#E3E3E3] flex flex-col justify-between"
            >
              <span className="text-[11px] text-[#616161] font-medium truncate">{item.name}</span>
              <span className="text-[18px] font-[650] text-[#1A1A1A] mt-1 tabular-nums">
                {item.qty} <span className="text-[11px] font-normal text-[#616161]">pcs</span>
              </span>
            </div>
          ))}
        </div>
      </PolarisCard>

      {/* Recent Officer Orders Card */}
      <PolarisCard
        title="Recent Officer Orders"
        actions={
          <button
            onClick={() => onNavigate('orders')}
            className="text-[12px] text-[#005BD3] hover:underline font-[550]"
          >
            View all orders
          </button>
        }
        flush={true}
      >
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left">
            <thead>
              <tr className="h-9 border-b border-[#E3E3E3] bg-white text-[12px] font-[450] text-[#616161]">
                <th className="px-3 w-16 text-left">Order</th>
                <th className="px-3 text-left">Customer</th>
                <th className="px-3 text-left">Items</th>
                <th className="px-3 text-right">Total</th>
                <th className="px-3 text-right">Due</th>
                <th className="px-3 text-center w-32">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E3E3E3] text-[13px]">
              {state.officerOrders.slice(0, 5).map((order) => (
                <tr
                  key={order.id}
                  onClick={() =>
                    onNavigate('order-details', {
                      orderNumber: order.orderNumber,
                      category: 'Officer',
                    })
                  }
                  className="h-[54px] hover:bg-[#F7F7F7] cursor-pointer transition-colors"
                >
                  <td className="px-3 font-[650] text-[#1A1A1A]">#{order.orderNumber}</td>
                  <td className="px-3 font-[550] text-[#1A1A1A]">
                    {order.customerName}
                    <span className="text-[11px] text-[#616161] font-normal ml-1">
                      (BD: {order.customerBdNumber})
                    </span>
                  </td>
                  <td className="px-3 text-[#616161] max-w-[200px] truncate">
                    {order.items.map((i) => `${i.name} ×${i.quantity}`).join(', ')}
                  </td>
                  <td className="px-3 text-right font-[550] text-[#1A1A1A] tabular-nums">
                    ৳{order.totalAmount}
                  </td>
                  <td
                    className={`px-3 text-right font-[650] tabular-nums ${
                      order.due > 0 ? 'text-[#8E0B21]' : 'text-[#616161]'
                    }`}
                  >
                    ৳{order.due}
                  </td>
                  <td className="px-3 text-center">
                    <StatusBadge status={order.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </PolarisCard>

      {/* Detail Modal / Drawer */}
      {activeDetailDrawer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-2xs animate-in fade-in">
          <div
            className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-[#E3E3E3] max-h-[85vh] flex flex-col"
            style={{ borderRadius: 'var(--radius-lg)' }}
          >
            <div className="h-12 px-4 bg-[#F1F1F1] border-b border-[#E3E3E3] flex items-center justify-between shrink-0">
              <h3 className="text-[14px] font-[650] text-[#1A1A1A] capitalize">
                {activeDetailDrawer} Details
              </h3>
              <button
                onClick={() => setActiveDetailDrawer(null)}
                className="p-1 rounded text-[#616161] hover:text-[#1A1A1A]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 overflow-y-auto space-y-2 text-[13px] flex-1">
              {activeDetailDrawer === 'overdue' && (
                <div className="divide-y divide-[#E3E3E3]">
                  {overdueOrders.map((o) => (
                    <div
                      key={o.id}
                      onClick={() => {
                        setActiveDetailDrawer(null);
                        onNavigate('order-details', { orderNumber: o.orderNumber, category: 'Officer' });
                      }}
                      className="py-2.5 flex items-center justify-between cursor-pointer hover:bg-[#F7F7F7] px-2 rounded-lg"
                    >
                      <div>
                        <div className="font-[650] text-[#1A1A1A]">
                          #{o.orderNumber} · {o.customerName}
                        </div>
                        <div className="text-[11px] text-[#8E0B21]">
                          Due Delivery: {o.deliveryDate} (Overdue)
                        </div>
                      </div>
                      <span className="text-[12px] font-[650] text-[#8E0B21] tabular-nums">
                        ৳{o.due}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {activeDetailDrawer === 'due' && (
                <div className="divide-y divide-[#E3E3E3]">
                  {customerDueAtPresent.list.map((o) => (
                    <div
                      key={o.id}
                      onClick={() => {
                        setActiveDetailDrawer(null);
                        onNavigate('order-details', { orderNumber: o.orderNumber, category: 'Officer' });
                      }}
                      className="py-2.5 flex items-center justify-between cursor-pointer hover:bg-[#F7F7F7] px-2 rounded-lg"
                    >
                      <div>
                        <div className="font-[650] text-[#1A1A1A]">
                          #{o.orderNumber} · {o.customerName}
                        </div>
                        <div className="text-[11px] text-[#616161]">
                          Status: {o.status} · BD: {o.customerBdNumber}
                        </div>
                      </div>
                      <span className="text-[12px] font-[650] text-[#8E0B21] tabular-nums">
                        ৳{o.due}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {activeDetailDrawer === 'collection' && (
                <div className="divide-y divide-[#E3E3E3]">
                  {collectionsInPeriod.list.map((c, idx) => (
                    <div key={idx} className="py-2.5 flex items-center justify-between px-2">
                      <div>
                        <div className="font-[650] text-[#1A1A1A]">
                          Order #{c.orderNumber} · {c.customerName}
                        </div>
                        <div className="text-[11px] text-[#616161]">
                          {c.type} on {c.date}
                        </div>
                      </div>
                      <span className="text-[12px] font-[650] text-[#0C5132] tabular-nums">
                        +৳{c.amount}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {(activeDetailDrawer === 'orders' || activeDetailDrawer === 'sales') && (
                <div className="divide-y divide-[#E3E3E3]">
                  {ordersInPeriod.map((o) => (
                    <div
                      key={o.id}
                      onClick={() => {
                        setActiveDetailDrawer(null);
                        onNavigate('order-details', { orderNumber: o.orderNumber, category: 'Officer' });
                      }}
                      className="py-2.5 flex items-center justify-between cursor-pointer hover:bg-[#F7F7F7] px-2 rounded-lg"
                    >
                      <div>
                        <div className="font-[650] text-[#1A1A1A]">
                          #{o.orderNumber} · {o.customerName}
                        </div>
                        <div className="text-[11px] text-[#616161]">{o.orderDate}</div>
                      </div>
                      <span className="text-[12px] font-[650] text-[#1A1A1A] tabular-nums">
                        ৳{o.totalAmount}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="px-4 py-3 bg-[#FAFAFA] border-t border-[#E3E3E3] flex justify-end">
              <button
                onClick={() => setActiveDetailDrawer(null)}
                className="h-7 px-3 rounded-lg bg-[#303030] text-white text-[13px] font-[550]"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </PolarisPage>
  );
};
