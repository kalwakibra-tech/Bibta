import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { Customer } from '../types/index.ts';
import { StatusBadge } from './StatusBadge.tsx';
import { ArrowLeft, Search, Calendar, ChevronRight, User, AlertCircle, X, Phone, Ruler } from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { PolarisTabs } from './polaris/PolarisTabs.tsx';
import { PolarisBadge } from './polaris/PolarisBadge.tsx';

interface CustomerHistoryScreenProps {
  initialBdNumber?: string;
  initialCategory?: 'Officer' | 'Airman';
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const CustomerHistoryScreen: React.FC<CustomerHistoryScreenProps> = ({
  initialBdNumber,
  initialCategory,
  onNavigate,
}) => {
  const { state } = useApp();

  const [activeCategory, setActiveCategory] = useState<'Officer' | 'Airman'>(
    initialCategory || 'Officer'
  );
  const [selectedBd, setSelectedBd] = useState<string | null>(initialBdNumber || null);
  const [searchQuery, setSearchQuery] = useState('');

  // Per-customer stats
  const customerStats = useMemo(() => {
    const stats: Record<string, { ordersCount: number; spent: number; due: number }> = {};

    for (const c of state.customers) {
      const key = `${c.category}-${c.bdNumber.trim().toUpperCase()}`;
      stats[key] = { ordersCount: 0, spent: 0, due: 0 };
    }

    for (const o of state.officerOrders) {
      const key = `Officer-${o.customerBdNumber.trim().toUpperCase()}`;
      if (!stats[key]) stats[key] = { ordersCount: 0, spent: 0, due: 0 };
      stats[key].ordersCount += 1;
      const spent = (Number(o.totalAmount) || 0) - (Number(o.discountAmount) || 0);
      stats[key].spent += spent;
      stats[key].due += Number(o.due) || 0;
    }

    for (const o of state.airmanOrders) {
      const key = `Airman-${o.customerBdNumber.trim().toUpperCase()}`;
      if (!stats[key]) stats[key] = { ordersCount: 0, spent: 0, due: 0 };
      stats[key].ordersCount += 1;
    }

    return stats;
  }, [state.customers, state.officerOrders, state.airmanOrders]);

  const customerList = useMemo(() => {
    return state.customers
      .filter((c) => c.category === activeCategory)
      .filter((c) => {
        if (!searchQuery.trim()) return true;
        const q = searchQuery.toLowerCase().trim();
        return (
          c.name.toLowerCase().includes(q) ||
          c.bdNumber.toLowerCase().includes(q) ||
          (c.phone || '').toLowerCase().includes(q)
        );
      });
  }, [state.customers, activeCategory, searchQuery]);

  // Selected customer details
  const selectedCustomer = useMemo(() => {
    if (!selectedBd) return null;
    return state.customers.find(
      (c) => c.category === activeCategory && c.bdNumber.trim().toUpperCase() === selectedBd.trim().toUpperCase()
    );
  }, [state.customers, activeCategory, selectedBd]);

  // Orders for selected customer
  const customerOrders = useMemo(() => {
    if (!selectedBd) return [];
    const norm = selectedBd.trim().toUpperCase();

    if (activeCategory === 'Officer') {
      return state.officerOrders
        .filter((o) => o.customerBdNumber.trim().toUpperCase() === norm)
        .sort((a, b) => b.orderNumber - a.orderNumber);
    } else {
      return state.airmanOrders
        .filter((o) => o.customerBdNumber.trim().toUpperCase() === norm)
        .sort((a, b) => b.orderNumber - a.orderNumber);
    }
  }, [state.officerOrders, state.airmanOrders, activeCategory, selectedBd]);

  const selectedStatsKey = selectedCustomer
    ? `${selectedCustomer.category}-${selectedCustomer.bdNumber.trim().toUpperCase()}`
    : '';
  const selectedStats = customerStats[selectedStatsKey] || { ordersCount: 0, spent: 0, due: 0 };

  // Latest measurements from previous orders
  const latestOfficerOrder = activeCategory === 'Officer' ? customerOrders[0] as any : null;
  const latestAirmanOrder = activeCategory === 'Airman' ? customerOrders[0] as any : null;
  const latestMeasurements = latestOfficerOrder || latestAirmanOrder;

  return (
    <PolarisPage
      title={selectedCustomer ? `${selectedCustomer.name}` : 'Customer History'}
      subtitle={
        selectedCustomer
          ? `${selectedCustomer.bdNumber} • ${selectedCustomer.category} Record`
          : 'Detailed order history and saved measurements per customer'
      }
      badge={
        selectedCustomer ? (
          <PolarisBadge tone={selectedStats.ordersCount > 0 ? 'info' : 'neutral'}>
            {selectedStats.ordersCount} Orders
          </PolarisBadge>
        ) : undefined
      }
      backAction={
        selectedCustomer
          ? () => setSelectedBd(null)
          : () => onNavigate('customers')
      }
      primaryAction={
        selectedCustomer
          ? {
              label:
                activeCategory === 'Officer' ? 'New Officer Order' : 'New Airman Order',
              onClick: () => {
                if (activeCategory === 'Officer') {
                  onNavigate('new-officer-order');
                } else {
                  onNavigate('new-airman-order');
                }
              },
            }
          : undefined
      }
    >
      {selectedCustomer ? (
        <div className="space-y-6">
          {/* Top KPI Cards for Selected Customer */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <PolarisCard>
              <div className="text-[11px] font-semibold text-[#616161] uppercase tracking-wider mb-1">
                Total Orders
              </div>
              <div className="text-2xl font-bold text-[#1A1A1A] tabular-nums">
                {selectedStats.ordersCount}
              </div>
              <div className="text-xs text-[#616161] mt-1">
                Lifetime placed orders
              </div>
            </PolarisCard>

            {activeCategory === 'Officer' ? (
              <>
                <PolarisCard>
                  <div className="text-[11px] font-semibold text-[#616161] uppercase tracking-wider mb-1">
                    Total Invoiced
                  </div>
                  <div className="text-2xl font-bold text-[#1A1A1A] tabular-nums">
                    ৳{selectedStats.spent.toLocaleString()}
                  </div>
                  <div className="text-xs text-[#616161] mt-1">
                    Net after discounts
                  </div>
                </PolarisCard>

                <PolarisCard>
                  <div className="text-[11px] font-semibold text-[#616161] uppercase tracking-wider mb-1">
                    Outstanding Due
                  </div>
                  <div
                    className={`text-2xl font-bold tabular-nums ${
                      selectedStats.due > 0 ? 'text-[#8E0B21]' : 'text-[#0C5132]'
                    }`}
                  >
                    ৳{selectedStats.due.toLocaleString()}
                  </div>
                  <div className="text-xs text-[#616161] mt-1">
                    {selectedStats.due > 0 ? 'Payment pending' : 'All accounts settled'}
                  </div>
                </PolarisCard>
              </>
            ) : (
              <>
                <PolarisCard>
                  <div className="text-[11px] font-semibold text-[#616161] uppercase tracking-wider mb-1">
                    Category
                  </div>
                  <div className="text-xl font-bold text-[#1A1A1A]">
                    Airman Service
                  </div>
                  <div className="text-xs text-[#616161] mt-1">
                    Military allocation
                  </div>
                </PolarisCard>

                <PolarisCard>
                  <div className="text-[11px] font-semibold text-[#616161] uppercase tracking-wider mb-1">
                    Phone Contact
                  </div>
                  <div className="text-xl font-bold text-[#1A1A1A] font-mono">
                    {selectedCustomer.phone || 'None'}
                  </div>
                  <div className="text-xs text-[#616161] mt-1">
                    Direct mobile
                  </div>
                </PolarisCard>
              </>
            )}
          </div>

          {/* Saved Measurements Card if Available */}
          {latestMeasurements && (
            <PolarisCard title="Latest Recorded Measurements">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Shirt Measurements */}
                {latestMeasurements.shirtMeasurements && (
                  <div className="p-4 rounded-lg border border-[#E3E3E3] bg-[#FAFBFB]">
                    <div className="flex items-center justify-between mb-3 border-b border-[#E3E3E3] pb-2">
                      <span className="font-semibold text-xs text-[#1A1A1A]">Shirt</span>
                      <span className="text-[11px] text-[#616161]">From Order #{latestMeasurements.orderNumber}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      {Object.entries(latestMeasurements.shirtMeasurements)
                        .filter(([k]) => !['handWrittenNotes', 'extraNotes'].includes(k))
                        .map(([k, val]) => (
                          <div key={k} className="p-1.5 bg-white border border-[#E3E3E3] rounded">
                            <span className="text-[10px] text-[#616161] uppercase block">{k}</span>
                            <span className="font-semibold text-[#1A1A1A]">{String(val || '—')}</span>
                          </div>
                        ))}
                    </div>
                  </div>
                )}

                {/* Pant Measurements */}
                {latestMeasurements.pantMeasurements && (
                  <div className="p-4 rounded-lg border border-[#E3E3E3] bg-[#FAFBFB]">
                    <div className="flex items-center justify-between mb-3 border-b border-[#E3E3E3] pb-2">
                      <span className="font-semibold text-xs text-[#1A1A1A]">Pant</span>
                      <span className="text-[11px] text-[#616161]">From Order #{latestMeasurements.orderNumber}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      {Object.entries(latestMeasurements.pantMeasurements)
                        .filter(([k]) => !['handWrittenNotes', 'extraNotes'].includes(k))
                        .map(([k, val]) => (
                          <div key={k} className="p-1.5 bg-white border border-[#E3E3E3] rounded">
                            <span className="text-[10px] text-[#616161] uppercase block">{k}</span>
                            <span className="font-semibold text-[#1A1A1A]">{String(val || '—')}</span>
                          </div>
                        ))}
                    </div>
                  </div>
                )}
              </div>
            </PolarisCard>
          )}

          {/* Orders History Table */}
          <PolarisCard title="Order History" flush>
            {customerOrders.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-[#E3E3E3] bg-[#FAFBFB] text-[#616161] font-semibold h-[37px]">
                      <th className="px-4 py-2 w-24">Order #</th>
                      <th className="px-4 py-2 w-28">Date</th>
                      <th className="px-4 py-2">Items</th>
                      <th className="px-4 py-2 w-28">Status</th>
                      {activeCategory === 'Officer' && (
                        <>
                          <th className="px-4 py-2 text-right w-24">Total</th>
                          <th className="px-4 py-2 text-right w-24">Due</th>
                        </>
                      )}
                      <th className="px-4 py-2 text-right w-28">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E3E3E3]">
                    {customerOrders.map((order: any) => (
                      <tr
                        key={order.orderNumber}
                        className="h-[54px] hover:bg-[#F9FAFB] transition-colors"
                      >
                        <td className="px-4 py-2 font-semibold text-[#1A1A1A] tabular-nums">
                          #{order.orderNumber}
                        </td>
                        <td className="px-4 py-2 text-[#4A4A4A] tabular-nums">
                          {order.orderDate}
                        </td>
                        <td className="px-4 py-2 text-[#4A4A4A]">
                          {order.items?.map((i: any) => `${i.name} ×${i.quantity}`).join(', ') || 'No items'}
                        </td>
                        <td className="px-4 py-2">
                          <StatusBadge status={order.status} />
                        </td>
                        {activeCategory === 'Officer' && (
                          <>
                            <td className="px-4 py-2 text-right tabular-nums font-medium text-[#1A1A1A]">
                              ৳{order.totalAmount}
                            </td>
                            <td className="px-4 py-2 text-right tabular-nums font-semibold">
                              {Number(order.due) > 0 ? (
                                <span className="text-[#8E0B21]">৳{order.due}</span>
                              ) : (
                                <span className="text-[#0C5132]">Paid</span>
                              )}
                            </td>
                          </>
                        )}
                        <td className="px-4 py-2 text-right">
                          <button
                            type="button"
                            onClick={() => onNavigate('order-details', { orderNumber: order.orderNumber, category: activeCategory })}
                            className="text-xs font-semibold text-[#005BD3] hover:underline"
                          >
                            View Details
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="py-12 text-center text-[#616161] text-xs">
                No orders recorded for this customer yet.
              </div>
            )}
          </PolarisCard>
        </div>
      ) : (
        /* Customer Selection Index View */
        <PolarisCard flush>
          <div className="border-b border-[#E3E3E3]">
            <PolarisTabs<'Officer' | 'Airman'>
              tabs={[
                { id: 'Officer', label: 'Officer Customers' },
                { id: 'Airman', label: 'Airman Customers' },
              ]}
              selectedTab={activeCategory}
              onSelectTab={(id: 'Officer' | 'Airman') => setActiveCategory(id)}
            />
          </div>

          <div className="p-3 border-b border-[#E3E3E3] bg-[#FAFBFB] flex items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#616161]" />
              <input
                type="text"
                placeholder="Search customer name, BD number, or phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-md text-[#303030] focus:outline-none focus:border-[#303030]"
              />
            </div>
            <div className="text-xs text-[#616161] font-medium">
              {customerList.length} customer{customerList.length === 1 ? '' : 's'}
            </div>
          </div>

          {customerList.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-[#E3E3E3] bg-[#FAFBFB] text-[#616161] font-semibold h-[37px]">
                    <th className="px-4 py-2 w-32">BD Number</th>
                    <th className="px-4 py-2">Customer Name</th>
                    <th className="px-4 py-2 w-36">Phone</th>
                    <th className="px-4 py-2 text-right w-24">Orders</th>
                    {activeCategory === 'Officer' && (
                      <>
                        <th className="px-4 py-2 text-right w-28">Total Spent</th>
                        <th className="px-4 py-2 text-right w-28">Due Balance</th>
                      </>
                    )}
                    <th className="px-4 py-2 text-right w-28">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E3E3E3]">
                  {customerList.map((customer) => {
                    const statsKey = `${customer.category}-${customer.bdNumber.trim().toUpperCase()}`;
                    const stats = customerStats[statsKey] || { ordersCount: 0, spent: 0, due: 0 };

                    return (
                      <tr
                        key={customer.id}
                        onClick={() => setSelectedBd(customer.bdNumber)}
                        className="h-[54px] hover:bg-[#F9FAFB] transition-colors cursor-pointer group"
                      >
                        <td className="px-4 py-2 font-mono font-medium text-[#005BD3]">
                          {customer.bdNumber}
                        </td>
                        <td className="px-4 py-2 font-semibold text-[#1A1A1A]">
                          {customer.name}
                        </td>
                        <td className="px-4 py-2 text-[#4A4A4A]">
                          {customer.phone || '—'}
                        </td>
                        <td className="px-4 py-2 text-right tabular-nums font-medium text-[#1A1A1A]">
                          {stats.ordersCount}
                        </td>
                        {activeCategory === 'Officer' && (
                          <>
                            <td className="px-4 py-2 text-right tabular-nums text-[#4A4A4A]">
                              ৳{stats.spent.toLocaleString()}
                            </td>
                            <td className="px-4 py-2 text-right tabular-nums font-semibold">
                              {stats.due > 0 ? (
                                <span className="text-[#8E0B21]">৳{stats.due.toLocaleString()}</span>
                              ) : (
                                <span className="text-[#0C5132]">৳0</span>
                              )}
                            </td>
                          </>
                        )}
                        <td className="px-4 py-2 text-right">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedBd(customer.bdNumber);
                            }}
                            className="inline-flex items-center space-x-1 text-xs font-semibold text-[#005BD3] hover:underline"
                          >
                            <span>History</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="py-12 text-center text-[#616161] text-xs">
              <User className="w-8 h-8 mx-auto mb-2 text-[#616161] opacity-50" />
              <p className="font-medium">No customers found</p>
              <p className="mt-1">Try another search keyword or switch between Officer and Airman categories.</p>
            </div>
          )}
        </PolarisCard>
      )}
    </PolarisPage>
  );
};
