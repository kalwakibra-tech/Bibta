import React from 'react';
import { OrderStatus } from '../types/index.ts';

interface StatusBadgeProps {
  status: OrderStatus;
  onChange?: (newStatus: OrderStatus) => void;
  interactive?: boolean;
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  onChange,
  interactive = false,
  className = '',
}) => {
  const getStatusStyles = (st: OrderStatus) => {
    switch (st) {
      case 'Pending':
        return 'bg-[#E3E3E3] text-[#4A4A4A]';
      case 'Cutting Slip – Done':
        return 'bg-[#C4E4F9] text-[#00527C]';
      case 'Delivered':
        return 'bg-[#AFFEBF] text-[#0C5132]';
      default:
        return 'bg-[#E3E3E3] text-[#4A4A4A]';
    }
  };

  if (!interactive || !onChange) {
    return (
      <span
        className={`inline-flex items-center h-5 px-2 rounded-lg text-[12px] leading-4 font-[450] whitespace-nowrap ${getStatusStyles(
          status
        )} ${className}`}
        style={{ borderRadius: 'var(--radius-sm)' }}
      >
        {status}
      </span>
    );
  }

  return (
    <select
      value={status}
      onChange={(e) => {
        e.stopPropagation();
        onChange(e.target.value as OrderStatus);
      }}
      onClick={(e) => e.stopPropagation()}
      aria-label="Order status"
      className={`h-5 text-[12px] leading-4 font-[550] rounded-lg px-2 border-0 cursor-pointer outline-none transition-colors ${getStatusStyles(
        status
      )} ${className}`}
      style={{ borderRadius: 'var(--radius-sm)' }}
    >
      <option value="Pending" className="bg-white text-[#303030]">
        Pending
      </option>
      <option value="Cutting Slip – Done" className="bg-white text-[#303030]">
        Cutting Slip – Done
      </option>
      <option value="Delivered" className="bg-white text-[#303030]">
        Delivered
      </option>
    </select>
  );
};
