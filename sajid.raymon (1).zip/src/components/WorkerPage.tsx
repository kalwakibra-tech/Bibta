import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { WorkerEntryRow, WorkItemDefinition } from '../types/index.ts';
import {
  formatDate,
  formatMonth,
  calculateWorkerMonthHishab,
} from '../utils/logic.ts';
import { MONTH_METADATA, MonthMeta } from '../utils/starterData.ts';
import {
  ArrowLeft,
  RotateCw,
  Download,
  Printer,
  Plus,
  Trash2,
  Save,
  Search,
  Check,
  AlertTriangle,
  X,
  ChevronDown,
  ChevronUp,
  Settings as SettingsIcon,
  Globe,
  Snowflake,
  Heart,
  Sprout,
  CloudRain,
  Flower2,
  Sun,
  CloudLightning,
  Umbrella,
  Wheat,
  Moon,
  Wind,
  Gift,
  FileText,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface WorkerPageProps {
  workerId: string;
  initialMonth?: string;
  onNavigate: (screen: ScreenName, params?: any) => void;
}

const MonthSymbolIcon: React.FC<{ symbol: string; className?: string }> = ({ symbol, className }) => {
  switch (symbol) {
    case 'Snowflake':
      return <Snowflake className={className} />;
    case 'Heart':
      return <Heart className={className} />;
    case 'Sprout':
      return <Sprout className={className} />;
    case 'CloudRain':
      return <CloudRain className={className} />;
    case 'Flower2':
      return <Flower2 className={className} />;
    case 'Sun':
      return <Sun className={className} />;
    case 'CloudLightning':
      return <CloudLightning className={className} />;
    case 'Umbrella':
      return <Umbrella className={className} />;
    case 'Wheat':
      return <Wheat className={className} />;
    case 'Moon':
      return <Moon className={className} />;
    case 'Wind':
      return <Wind className={className} />;
    case 'Gift':
      return <Gift className={className} />;
    default:
      return <FileText className={className} />;
  }
};

export const WorkerPage: React.FC<WorkerPageProps> = ({
  workerId,
  initialMonth,
  onNavigate,
}) => {
  const { state, saveWorkerRows } = useApp();

  const worker = state.workers.find((w) => w.id === workerId);
  const runningMonth = formatMonth();
  const [selectedMonth, setSelectedMonth] = useState(initialMonth || runningMonth);
  const [lang, setLang] = useState<'EN' | 'BN'>('EN');

  const [searchFilter, setSearchFilter] = useState('');
  const [toastMessage, setToastMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isDirty, setIsDirty] = useState(false);
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [khorachHistoryOpen, setKhorachHistoryOpen] = useState(false);

  // Month styling (table 4.5)
  const monthMeta = useMemo(() => {
    const monthNum = selectedMonth.slice(5, 7);
    return MONTH_METADATA.find((m) => m.numStr === monthNum) || MONTH_METADATA[0];
  }, [selectedMonth]);

  // Unsaved changes beforeunload handler
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isDirty) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [isDirty]);

  // Rows state
  const [rows, setRows] = useState<WorkerEntryRow[]>([]);

  // Default date for new row in selected month (FIX-12: first day of selected month or today if current month)
  const getDefaultRowDate = () => {
    if (selectedMonth === runningMonth) {
      return formatDate();
    }
    return `${selectedMonth}-01`;
  };

  const createBlankRow = (): WorkerEntryRow => ({
    id: `row-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    workerId,
    date: getDefaultRowDate(),
    serial: '',
    bdNumber: '',
    name: '',
    item: '',
    quantity: 1,
    unitPrice: 0,
    totalTaka: 0,
    khorochDate: '',
    khoroch: 0,
  });

  // Load existing entries followed by 10 blank rows (FIX-12)
  useEffect(() => {
    const existing = state.workerRows.filter((r) => {
      if (r.workerId !== workerId) return false;
      const rowMonth = (r.date || '').slice(0, 7);
      const khorochMonth = (r.khorochDate || r.date || '').slice(0, 7);
      return rowMonth === selectedMonth || khorochMonth === selectedMonth;
    });

    const blankTen = Array.from({ length: 10 }, () => createBlankRow());
    setRows([...existing, ...blankTen]);
    setIsDirty(false);
  }, [workerId, selectedMonth]);

  const handleRowChange = (index: number, field: keyof WorkerEntryRow, value: any) => {
    const updated = [...rows];
    (updated[index] as any)[field] = value;

    if (field === 'quantity' || field === 'unitPrice') {
      const q = Number(field === 'quantity' ? value : updated[index].quantity) || 0;
      const p = Number(field === 'unitPrice' ? value : updated[index].unitPrice) || 0;
      updated[index].totalTaka = q * p;
    }

    setRows(updated);
    setIsDirty(true);
  };

  const handleItemSelect = (index: number, itemName: string) => {
    const updated = [...rows];
    updated[index].item = itemName;

    const workItem = state.settings.workItems.find((w) => w.name === itemName);
    if (workItem) {
      updated[index].unitPrice = workItem.rate;
    }

    const qty = Number(updated[index].quantity) || 1;
    const rate = Number(updated[index].unitPrice) || 0;
    updated[index].totalTaka = qty * rate;

    setRows(updated);
    setIsDirty(true);
  };

  const handleDeleteRow = (index: number) => {
    const updated = rows.filter((_, i) => i !== index);
    setRows(updated);
    setIsDirty(true);
  };

  const handleAdd10Rows = () => {
    const newTen = Array.from({ length: 10 }, () => createBlankRow());
    setRows((prev) => [...prev, ...newTen]);
    setIsDirty(true);
  };

  // Month Hishab calculations for footer
  const hishab = useMemo(() => {
    return calculateWorkerMonthHishab(
      workerId,
      state.workerRows,
      state.workerPayments,
      selectedMonth
    );
  }, [workerId, state.workerRows, state.workerPayments, selectedMonth]);

  // Live footer totals for currently visible rows
  const visibleTotals = useMemo(() => {
    let totalTaka = 0;
    let totalKhoroch = 0;
    for (const r of rows) {
      if (r.item && (r.quantity || 0) > 0) {
        totalTaka += Number(r.totalTaka) || 0;
      }
      if (r.khoroch) {
        totalKhoroch += Number(r.khoroch) || 0;
      }
    }
    return {
      totalTaka,
      totalKhoroch,
      totalPayable: totalTaka - totalKhoroch,
    };
  }, [rows]);

  const handleSave = () => {
    setErrorMessage('');

    // Save only rows that have an item or khoroch
    const res = saveWorkerRows(workerId, rows);
    if (!res.success) {
      setErrorMessage(res.error || 'Failed to save sheet.');
      return;
    }

    setIsDirty(false);
    setToastMessage('Sheet saved successfully.');
    setTimeout(() => setToastMessage(''), 3000);
  };

  const handleRecalculate = () => {
    setRows((prev) =>
      prev.map((r) => ({
        ...r,
        totalTaka: (Number(r.quantity) || 0) * (Number(r.unitPrice) || 0),
      }))
    );
    setToastMessage('Totals recalculated');
    setTimeout(() => setToastMessage(''), 3000);
  };

  const handleDownloadCSV = () => {
    const headers = [
      'Date',
      'Serial',
      'Name',
      'Item',
      'Quantity',
      'Unit Price',
      'Total Taka',
      'Khorach Date',
      'Khorach',
      'Total Payable',
    ];

    const validRows = rows.filter((r) => r.item || r.khoroch);
    const csvRows = validRows.map((r) => [
      r.date,
      `"${r.serial || ''}"`,
      `"${(r.name || '').replace(/"/g, '""')}"`,
      `"${(r.item || '').replace(/"/g, '""')}"`,
      r.quantity || 1,
      r.unitPrice || 0,
      r.totalTaka || 0,
      r.khorochDate || '',
      r.khoroch || 0,
      (Number(r.totalTaka) || 0) - (Number(r.khoroch) || 0),
    ]);

    csvRows.push([]);
    csvRows.push([
      'Total',
      '',
      '',
      '',
      '',
      '',
      visibleTotals.totalTaka,
      '',
      visibleTotals.totalKhoroch,
      visibleTotals.totalPayable,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...csvRows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `raymond_${worker?.name}_${selectedMonth}_entries.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Khorach History rows (FIX-14)
  const khorachHistoryRows = useMemo(() => {
    const list = rows
      .filter((r) => Number(r.khoroch) > 0)
      .map((r) => ({
        date: r.khorochDate || r.date,
        amount: Number(r.khoroch) || 0,
        note: r.name ? `For: ${r.name}` : r.serial ? `Serial: #${r.serial}` : '',
      }))
      .sort((a, b) => (a.date > b.date ? 1 : -1));

    let running = 0;
    return list.map((item) => {
      running += item.amount;
      return { ...item, runningTotal: running };
    });
  }, [rows]);

  // Filter rows by search term
  const displayedRows = useMemo(() => {
    if (!searchFilter.trim()) return rows;
    const q = searchFilter.toLowerCase().trim();
    return rows.filter((r) => {
      const serialMatch = (r.serial || '').toLowerCase().includes(q);
      const nameMatch = (r.name || '').toLowerCase().includes(q);
      const itemMatch = (r.item || '').toLowerCase().includes(q);
      return serialMatch || nameMatch || itemMatch;
    });
  }, [rows, searchFilter]);

  if (!worker) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 text-center text-sm text-gray-500">
        Worker not found.
      </div>
    );
  }

  const handleBackClick = () => {
    if (isDirty) {
      setCancelModalOpen(true);
      return;
    }
    onNavigate('staff-management');
  };

  return (
    <div
      style={{ backgroundColor: monthMeta.tint }}
      className="min-h-screen pb-12 transition-colors duration-300"
    >
      {/* Unsaved Changes Modal (FIX-08) */}
      {cancelModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/40 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-gray-100">
            <h3 className="text-lg font-bold text-gray-900 mb-2">Unsaved Work</h3>
            <p className="text-sm text-gray-600 mb-6">
              You have unsaved changes in this month sheet. Do you want to stay or discard your changes?
            </p>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setCancelModalOpen(false)}
                className="px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-100 rounded-lg"
              >
                Stay
              </button>
              <button
                type="button"
                onClick={() => {
                  setCancelModalOpen(false);
                  setIsDirty(false);
                  onNavigate('staff-management');
                }}
                className="px-4 py-2 text-sm font-semibold text-red-600 hover:bg-red-50 rounded-lg"
              >
                Leave without saving
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Month Colour Header Band (FIX-11 & FIX-12) */}
      <div
        style={{ backgroundColor: monthMeta.strong }}
        className="text-white px-4 sm:px-6 lg:px-8 py-5 shadow-sm"
      >
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center space-x-3.5">
            <button
              onClick={handleBackClick}
              className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
              aria-label="Back to workers list"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center text-white shrink-0">
                <MonthSymbolIcon symbol={monthMeta.symbol} className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h1 className="text-xl sm:text-2xl font-black tracking-tight">{worker.name}</h1>
                  {worker.banglaName && (
                    <span className="text-sm text-white/80 font-normal">({worker.banglaName})</span>
                  )}
                </div>
                <p className="text-xs text-white/90 font-medium">
                  {lang === 'BN' ? monthMeta.banglaName : monthMeta.name} {selectedMonth.slice(0, 4)} ·{' '}
                  {lang === 'BN' ? 'কাজের লেজার ও খোরচ খাতা' : 'Monthly Work Ledger & Khorach'}
                </p>
              </div>
            </div>
          </div>

          {/* Action buttons on top bar */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Language Switch */}
            <button
              onClick={() => setLang(lang === 'EN' ? 'BN' : 'EN')}
              className="px-2.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-white/15 hover:bg-white/25 flex items-center space-x-1"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{lang === 'EN' ? 'বাংলা' : 'EN'}</span>
            </button>

            {/* Recalculate */}
            <button
              onClick={handleRecalculate}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-white/15 hover:bg-white/25 flex items-center space-x-1"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Recalculate</span>
            </button>

            {/* CSV */}
            <button
              onClick={handleDownloadCSV}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-white/15 hover:bg-white/25 flex items-center space-x-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>CSV</span>
            </button>

            {/* Print Payslip / Statement (FIX-14) */}
            <button
              onClick={() =>
                onNavigate('print-worker-statement', { workerId: worker.id, month: selectedMonth })
              }
              className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-gray-900 bg-white hover:bg-gray-100 flex items-center space-x-1 shadow-xs"
            >
              <Printer className="w-3.5 h-3.5 text-gray-800" />
              <span>Print Payslip</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Toast Notification */}
        {toastMessage && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold rounded-xl flex items-center justify-between shadow-xs">
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>{toastMessage}</span>
            </div>
            <button onClick={() => setToastMessage('')} className="text-emerald-900">
              ✕
            </button>
          </div>
        )}

        {/* Error Message */}
        {errorMessage && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-sm font-medium rounded-xl flex items-center justify-between">
            <span>{errorMessage}</span>
            <button onClick={() => setErrorMessage('')} className="text-red-900 font-bold">
              ✕
            </button>
          </div>
        )}

        {/* Month Selector & Search Header */}
        <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <label className="text-xs font-bold text-gray-700">Month:</label>
            <input
              type="month"
              value={selectedMonth}
              onChange={(e) => {
                if (e.target.value) setSelectedMonth(e.target.value);
              }}
              className="px-3 py-1.5 text-sm font-bold border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search by name or item..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 shadow-2xs"
            />
            {searchFilter && (
              <button
                onClick={() => setSearchFilter('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Entry List Card (FIX-12) */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-3 bg-gray-50">
            <div className="flex items-center space-x-2">
              <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wider">Entry List</h2>
              <span className="text-xs text-gray-500">({rows.length} rows)</span>
              {isDirty && (
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                  Unsaved changes
                </span>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={handleAdd10Rows}
                className="px-3 py-1.5 border border-gray-300 rounded-lg text-xs font-semibold text-gray-700 bg-white hover:bg-gray-50 shadow-2xs"
              >
                Add 10 Rows
              </button>
              <button
                type="button"
                onClick={handleSave}
                style={{ backgroundColor: monthMeta.strong }}
                className="px-4 py-1.5 text-white rounded-lg text-xs font-bold shadow-xs flex items-center space-x-1 hover:opacity-90"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save</span>
              </button>
            </div>
          </div>

          {/* Month Entry Table (10 columns in exact order + delete icon) */}
          <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
            <table className="min-w-full divide-y divide-gray-200 text-xs">
              <thead
                style={{ backgroundColor: monthMeta.strong }}
                className="text-white font-bold sticky top-0 z-10"
              >
                <tr>
                  <th className="px-2.5 py-2.5 text-left w-28">Date</th>
                  <th className="px-2.5 py-2.5 text-left w-20">Serial</th>
                  <th className="px-2.5 py-2.5 text-left w-32">Name</th>
                  <th className="px-2.5 py-2.5 text-left w-48">Item</th>
                  <th className="px-2 py-2.5 text-center w-16">Quantity</th>
                  <th className="px-2 py-2.5 text-right w-20">Unit Price</th>
                  <th className="px-3 py-2.5 text-right w-24">Total Taka</th>
                  <th className="px-2.5 py-2.5 text-left w-28">Khorach Date</th>
                  <th className="px-2.5 py-2.5 text-right w-24">Khorach</th>
                  <th className="px-3 py-2.5 text-right w-24">Total Payable</th>
                  <th className="px-2 py-2.5 text-center w-10"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 bg-white">
                {displayedRows.map((row, idx) => {
                  const rowPayable = (Number(row.totalTaka) || 0) - (Number(row.khoroch) || 0);

                  return (
                    <tr key={row.id || idx} className="hover:bg-blue-50/30">
                      {/* 1. Date */}
                      <td className="px-2 py-1.5">
                        <input
                          type="date"
                          value={row.date}
                          onChange={(e) => handleRowChange(idx, 'date', e.target.value)}
                          className="w-full px-1.5 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 font-medium"
                        />
                      </td>

                      {/* 2. Serial (free text) */}
                      <td className="px-2 py-1.5">
                        <input
                          type="text"
                          value={row.serial}
                          onChange={(e) => handleRowChange(idx, 'serial', e.target.value)}
                          placeholder="e.g. 521"
                          className="w-full px-1.5 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 font-medium"
                        />
                      </td>

                      {/* 3. Name (free text) */}
                      <td className="px-2 py-1.5">
                        <input
                          type="text"
                          value={row.name}
                          onChange={(e) => handleRowChange(idx, 'name', e.target.value)}
                          placeholder="Customer name"
                          className="w-full px-1.5 py-1 text-xs border border-gray-300 rounded font-medium"
                        />
                      </td>

                      {/* 4. Item (Worker Items with prices & Manage Items link) */}
                      <td className="px-2 py-1.5">
                        <select
                          value={row.item}
                          onChange={(e) => {
                            if (e.target.value === '__manage__') {
                              onNavigate('settings');
                            } else {
                              handleItemSelect(idx, e.target.value);
                            }
                          }}
                          className="w-full px-1.5 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 font-medium"
                        >
                          <option value="">-- Choose item --</option>
                          {state.settings.workItems.map((wi) => (
                            <option key={wi.id} value={wi.name}>
                              {wi.name} — ৳{wi.rate}
                            </option>
                          ))}
                          <option value="__manage__" className="font-bold text-blue-600">
                            ⚙ Manage Items...
                          </option>
                        </select>
                      </td>

                      {/* 5. Quantity */}
                      <td className="px-2 py-1.5 text-center">
                        <input
                          type="number"
                          inputMode="numeric"
                          min="1"
                          value={row.quantity}
                          onChange={(e) =>
                            handleRowChange(idx, 'quantity', parseInt(e.target.value, 10) || 0)
                          }
                          className="w-14 px-1.5 py-1 text-xs text-center border border-gray-300 rounded font-medium"
                        />
                      </td>

                      {/* 6. Unit Price (stays editable) */}
                      <td className="px-2 py-1.5 text-right">
                        <input
                          type="number"
                          inputMode="numeric"
                          min="0"
                          value={row.unitPrice}
                          onChange={(e) =>
                            handleRowChange(idx, 'unitPrice', parseFloat(e.target.value) || 0)
                          }
                          className="w-16 px-1.5 py-1 text-xs text-right border border-gray-300 rounded font-medium"
                        />
                      </td>

                      {/* 7. Total Taka */}
                      <td className="px-3 py-1.5 text-right font-bold text-gray-900">
                        ৳{row.totalTaka}
                      </td>

                      {/* 8. Khorach Date (starts blank) */}
                      <td className="px-2 py-1.5">
                        <input
                          type="date"
                          value={row.khorochDate || ''}
                          onChange={(e) => handleRowChange(idx, 'khorochDate', e.target.value)}
                          className="w-full px-1.5 py-1 text-xs border border-gray-300 rounded font-medium"
                        />
                      </td>

                      {/* 9. Khorach */}
                      <td className="px-2 py-1.5 text-right">
                        <input
                          type="number"
                          inputMode="numeric"
                          min="0"
                          value={row.khoroch || 0}
                          onChange={(e) =>
                            handleRowChange(idx, 'khoroch', parseFloat(e.target.value) || 0)
                          }
                          className="w-20 px-1.5 py-1 text-xs text-right border border-gray-300 rounded text-amber-800 font-semibold"
                        />
                      </td>

                      {/* 10. Total Payable */}
                      <td
                        className={`px-3 py-1.5 text-right font-bold ${
                          rowPayable < 0 ? 'text-red-600' : 'text-gray-900'
                        }`}
                      >
                        ৳{rowPayable}
                      </td>

                      {/* 11. Delete Row */}
                      <td className="px-2 py-1.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteRow(idx)}
                          className="text-gray-300 hover:text-red-600 p-0.5"
                          title="Delete row"
                          aria-label={`Delete row ${idx + 1}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Footer: Total (taka), Total Khorach, Total Payable for visible month (FIX-12) */}
          <div className="bg-gray-50 border-t border-gray-200 p-4 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-bold text-center">
            <div className="bg-white p-3 rounded-lg border border-gray-200 shadow-2xs">
              <span className="text-gray-500 block text-[11px] uppercase tracking-wider">
                Total (Taka)
              </span>
              <span className="text-base text-gray-900 font-extrabold">
                ৳{visibleTotals.totalTaka.toLocaleString()}
              </span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-gray-200 shadow-2xs">
              <span className="text-gray-500 block text-[11px] uppercase tracking-wider">
                Total Khorach
              </span>
              <span className="text-base text-amber-700 font-extrabold">
                ৳{visibleTotals.totalKhoroch.toLocaleString()}
              </span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-gray-200 shadow-2xs">
              <span className="text-gray-500 block text-[11px] uppercase tracking-wider">
                Total Payable
              </span>
              <span
                className={`text-base font-extrabold ${
                  visibleTotals.totalPayable < 0 ? 'text-red-600' : 'text-emerald-700'
                }`}
              >
                ৳{visibleTotals.totalPayable.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Collapsible Khorach History Section (FIX-14) */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-xs overflow-hidden">
          <button
            type="button"
            onClick={() => setKhorachHistoryOpen(!khorachHistoryOpen)}
            className="w-full p-4 flex items-center justify-between bg-gray-50 hover:bg-gray-100/80 text-left transition-colors"
          >
            <div className="flex items-center space-x-2">
              <h3 className="text-sm font-bold text-gray-900">Khorach History</h3>
              <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-amber-100 text-amber-800">
                {khorachHistoryRows.length} entries
              </span>
            </div>
            <div className="flex items-center space-x-2 text-xs text-gray-500">
              <span>Running Total: ৳{visibleTotals.totalKhoroch.toLocaleString()}</span>
              {khorachHistoryOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </div>
          </button>

          {khorachHistoryOpen && (
            <div className="p-4 border-t border-gray-100">
              {khorachHistoryRows.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200 text-xs">
                    <thead className="bg-gray-50 text-gray-600 font-semibold">
                      <tr>
                        <th className="px-3 py-2 text-left">Date</th>
                        <th className="px-3 py-2 text-left">Details</th>
                        <th className="px-3 py-2 text-right">Khorach Amount</th>
                        <th className="px-3 py-2 text-right">Running Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 bg-white">
                      {khorachHistoryRows.map((entry, i) => (
                        <tr key={i} className="hover:bg-amber-50/30">
                          <td className="px-3 py-2 font-medium text-gray-800">{entry.date}</td>
                          <td className="px-3 py-2 text-gray-600">{entry.note || 'Advance expense'}</td>
                          <td className="px-3 py-2 text-right font-bold text-amber-800">
                            ৳{entry.amount.toLocaleString()}
                          </td>
                          <td className="px-3 py-2 text-right font-extrabold text-gray-900">
                            ৳{entry.runningTotal.toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-6 text-gray-400 text-xs">
                  No Khorach amounts recorded for this month.
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
