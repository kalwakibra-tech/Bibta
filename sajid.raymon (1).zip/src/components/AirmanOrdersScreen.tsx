import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { AirmanOrder, OrderStatus } from '../types/index.ts';
import { StatusBadge } from './StatusBadge.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { PolarisTabs } from './polaris/PolarisTabs.tsx';
import {
  Plus,
  Search,
  Printer,
  Edit2,
  Trash2,
  Truck,
  Plane,
  X,
  AlertCircle,
  Scissors,
  AlertTriangle,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface AirmanOrdersScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const AirmanOrdersScreen: React.FC<AirmanOrdersScreenProps> = ({ onNavigate }) => {
  const { state, loading, updateAirmanOrderStatus, deleteAirmanOrder } = useApp();

  const [selectedYear, setSelectedYear] = useState<string>('All');
  const [activeTab, setActiveTab] = useState<'All' | OrderStatus>('All');
  const [selectedUniformFilter, setSelectedUniformFilter] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');

  // Delete Dialog State (Two-step delete)
  const [deleteTargetOrder, setDeleteTargetOrder] = useState<AirmanOrder | null>(null);
  const [deleteStep, setDeleteStep] = useState<1 | 2>(1);

  // Filter orders by Running Year first
  const yearOrders = useMemo(() => {
    if (selectedYear === 'All') return state.airmanOrders;
    return state.airmanOrders.filter((o) => o.runningYear === selectedYear);
  }, [state.airmanOrders, selectedYear]);

  // Dynamic Uniform Items from settings
  const uniformItemsList = useMemo(() => {
    return state.settings.airmanItems || [];
  }, [state.settings.airmanItems]);

  // Calculate counts for each uniform category in the current year
  const uniformCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    uniformItemsList.forEach((it) => {
      counts[it.name] = 0;
    });

    yearOrders.forEach((order) => {
      order.items.forEach((item) => {
        if (counts[item.name] !== undefined) {
          counts[item.name] += item.quantity || 1;
        } else {
          counts[item.name] = (counts[item.name] || 0) + (item.quantity || 1);
        }
      });
    });

    return counts;
  }, [yearOrders, uniformItemsList]);

  // Tab counts
  const tabCounts = useMemo(() => {
    return {
      All: yearOrders.length,
      Pending: yearOrders.filter((o) => o.status === 'Pending').length,
      'Cutting Slip – Done': yearOrders.filter((o) => o.status === 'Cutting Slip – Done').length,
      Delivered: yearOrders.filter((o) => o.status === 'Delivered').length,
    };
  }, [yearOrders]);

  // Filtered and Sorted Orders
  const filteredOrders = useMemo(() => {
    return yearOrders
      .filter((order) => {
        if (activeTab !== 'All' && order.status !== activeTab) return false;

        // Uniform item card filter
        if (selectedUniformFilter) {
          const hasItem = order.items.some((item) => item.name === selectedUniformFilter);
          if (!hasItem) return false;
        }

        // Search query: name, phone, BD number, order number or IV-Number
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchesName = (order.customerName || '').toLowerCase().includes(q);
          const matchesPhone = (order.customerPhone || '').toLowerCase().includes(q);
          const matchesBd = order.customerBdNumber.toLowerCase().includes(q);
          const matchesOrderNum = String(order.orderNumber).includes(q) || `#${order.orderNumber}`.includes(q);
          const matchesIv = order.items.some((i) => (i.ivNumber || '').toLowerCase().includes(q));

          if (!matchesName && !matchesPhone && !matchesBd && !matchesOrderNum && !matchesIv) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortOrder === 'newest') return b.orderNumber - a.orderNumber;
        return a.orderNumber - b.orderNumber;
      });
  }, [yearOrders, activeTab, selectedUniformFilter, searchQuery, sortOrder]);

  const handleDeleteClick = (e: React.MouseEvent, order: AirmanOrder) => {
    e.stopPropagation();
    setDeleteTargetOrder(order);
    setDeleteStep(1);
  };

  const handleConfirmDeleteStep1 = () => {
    setDeleteStep(2);
  };

  const handleConfirmDeleteStep2 = () => {
    if (deleteTargetOrder) {
      deleteAirmanOrder(deleteTargetOrder.orderNumber);
      setDeleteTargetOrder(null);
      setDeleteStep(1);
    }
  };

  return (
    <PolarisPage
      title="Airman Orders"
      subtitle="Yearly bulk uniform batch orders with IV-Numbers and cutting slips"
      secondaryActions={[
        {
          label: 'Delivery',
          onClick: () => onNavigate('delivery'),
          icon: <Truck className="w-3.5 h-3.5" />,
        },
      ]}
      primaryAction={{
        label: 'New Airman Order',
        onClick: () => onNavigate('new-airman-order'),
        icon: <Plus className="w-3.5 h-3.5" />,
      }}
      fullWidth={true}
    >
      {/* Running Year Selector & Uniform Cards */}
      <div className="space-y-3">
        {/* Running Year Filter Bar */}
        <div className="flex items-center space-x-2">
          <span className="text-[13px] font-[550] text-[#616161]">Running Year:</span>
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(e.target.value)}
            className="h-7 px-2.5 text-[12px] bg-white border border-[#E3E3E3] rounded-lg text-[#303030] font-[550] focus:outline-none focus:border-[#303030] cursor-pointer shadow-2xs"
          >
            <option value="All">All Years</option>
            {state.settings.runningYears.map((yr) => (
              <option key={yr} value={yr}>
                {yr}
              </option>
            ))}
          </select>
          {selectedUniformFilter && (
            <button
              onClick={() => setSelectedUniformFilter(null)}
              className="text-[12px] text-[#005BD3] hover:underline font-medium ml-2"
            >
              Clear {selectedUniformFilter} filter
            </button>
          )}
        </div>

        {/* Uniform Item Summary Cards (Pure Quantity, No Money) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {uniformItemsList.map((item) => {
            const count = uniformCounts[item.name] || 0;
            const isSelected = selectedUniformFilter === item.name;

            return (
              <div
                key={item.id}
                onClick={() =>
                  setSelectedUniformFilter((prev) => (prev === item.name ? null : item.name))
                }
                className={`p-3 bg-white rounded-xl border transition-all cursor-pointer shadow-[0_1px_0_rgba(26,26,26,0.07)] ${
                  isSelected
                    ? 'border-[#303030] ring-1 ring-[#303030] bg-[#FAFAFA]'
                    : 'border-[#E3E3E3] hover:border-[#8A8A8A]'
                }`}
              >
                <div className="text-[11px] font-[450] text-[#616161] truncate">
                  {item.name}
                </div>
                <div className="text-[18px] font-[650] text-[#1A1A1A] mt-1 tabular-nums">
                  {count} <span className="text-[11px] font-normal text-[#616161]">pcs</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Table Card */}
      <PolarisCard flush={true}>
        {/* Saved Views Tabs & Search/Sort */}
        <PolarisTabs
          tabs={[
            { id: 'All', label: 'All', count: tabCounts.All },
            { id: 'Pending', label: 'Pending', count: tabCounts.Pending },
            { id: 'Cutting Slip – Done', label: 'Cutting Slip – Done', count: tabCounts['Cutting Slip – Done'] },
            { id: 'Delivered', label: 'Delivered', count: tabCounts.Delivered },
          ]}
          selectedTab={activeTab}
          onSelectTab={(tabId) => setActiveTab(tabId as any)}
          tools={
            <div className="flex items-center space-x-2">
              <div className="relative w-48 sm:w-60">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#8A8A8A]" />
                <input
                  type="text"
                  placeholder="Search name, BD, IV-Number..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full h-7 pl-8 pr-6 text-[12px] bg-white border border-[#E3E3E3] rounded-lg focus:outline-none focus:border-[#303030] text-[#303030]"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-[#8A8A8A] hover:text-[#303030]"
                    aria-label="Clear filter"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>

              <select
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value as 'newest' | 'oldest')}
                className="h-7 pl-2.5 pr-6 text-[12px] bg-white border border-[#E3E3E3] rounded-lg text-[#303030] focus:outline-none focus:border-[#303030] cursor-pointer"
                aria-label="Sort order"
              >
                <option value="newest">Newest first</option>
                <option value="oldest">Oldest first</option>
              </select>
            </div>
          }
        />

        {/* Loading State */}
        {loading && (
          <div className="p-8 space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-12 bg-[#F1F1F1] rounded-lg animate-pulse" />
            ))}
          </div>
        )}

        {/* Empty State */}
        {!loading && filteredOrders.length === 0 && (
          <div className="p-12 text-center text-[#616161]">
            <AlertCircle className="w-10 h-10 mx-auto text-[#8A8A8A] mb-2 opacity-50" />
            <h3 className="text-[14px] font-[650] text-[#1A1A1A]">No airman orders found</h3>
            <p className="text-[13px] text-[#616161] mt-1">
              {searchQuery || selectedUniformFilter || activeTab !== 'All'
                ? 'Try adjusting your search query, year, or tab filter.'
                : 'Create your first Airman batch order to begin.'}
            </p>
          </div>
        )}

        {/* 54px Polaris IndexTable */}
        {!loading && filteredOrders.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left">
              <thead>
                <tr className="h-9 border-b border-[#E3E3E3] bg-white text-[13px] font-[450] text-[#616161]">
                  <th className="px-3 w-16 text-left">Order</th>
                  <th className="px-3 text-left">Customer</th>
                  <th className="px-3 text-left">Items & IV-Number</th>
                  <th className="px-3 text-left">Year</th>
                  <th className="px-3 text-left">Trade / Office</th>
                  <th className="px-3 text-center w-36">Status</th>
                  <th className="px-3 text-right w-32">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E3E3E3] text-[13px]">
                {filteredOrders.map((order) => {
                  return (
                    <tr
                      key={order.id}
                      onClick={() =>
                        onNavigate('order-details', {
                          orderNumber: order.orderNumber,
                          category: 'Airman',
                        })
                      }
                      className="h-[54px] hover:bg-[#F7F7F7] cursor-pointer transition-colors group"
                    >
                      {/* Order # */}
                      <td className="px-3 font-[650] text-[#1A1A1A]">
                        #{order.orderNumber}
                      </td>

                      {/* Customer & BD */}
                      <td className="px-3">
                        <div className="font-[550] text-[#1A1A1A] line-clamp-1">
                          {order.customerName || `Airman ${order.customerBdNumber}`}
                        </div>
                        <div className="text-[11px] text-[#616161] mt-0.5">
                          BD: {order.customerBdNumber}
                        </div>
                      </td>

                      {/* Items & IV-Number */}
                      <td className="px-3 text-[#616161] max-w-[240px]">
                        <div className="line-clamp-1">
                          {order.items
                            .map((i) => `${i.name} ×${i.quantity} (IV:${i.ivNumber || '—'})`)
                            .join(', ')}
                        </div>
                      </td>

                      {/* Running Year */}
                      <td className="px-3 text-[12px] text-[#303030] font-[550]">
                        {order.runningYear}
                      </td>

                      {/* Trade / Office */}
                      <td className="px-3 text-[12px] text-[#616161]">
                        <div>{order.trade || '—'}</div>
                        <div className="text-[11px] text-[#8A8A8A]">{order.office || '—'}</div>
                      </td>

                      {/* Status */}
                      <td className="px-3 text-center" onClick={(e) => e.stopPropagation()}>
                        <StatusBadge
                          status={order.status}
                          interactive={true}
                          onChange={(newStatus) =>
                            updateAirmanOrderStatus(order.orderNumber, newStatus)
                          }
                        />
                      </td>

                      {/* Actions */}
                      <td className="px-3 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end space-x-1">
                          <button
                            onClick={() =>
                              onNavigate('print-slip', {
                                orderNumber: order.orderNumber,
                                category: 'Airman',
                              })
                            }
                            title="Cutting Slip"
                            className="p-1 text-[#616161] hover:text-[#1A1A1A] hover:bg-[#EBEBEB] rounded"
                            aria-label="Cutting slip"
                          >
                            <Scissors className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() =>
                              onNavigate('edit-airman-order', {
                                orderNumber: order.orderNumber,
                              })
                            }
                            title="Edit"
                            className="p-1 text-[#616161] hover:text-[#005BD3] hover:bg-[#EBEBEB] rounded"
                            aria-label="Edit order"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => handleDeleteClick(e, order)}
                            title="Delete"
                            className="p-1 text-[#616161] hover:text-[#8E0B21] hover:bg-[#FEE9E8] rounded"
                            aria-label="Delete order"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </PolarisCard>

      {/* Two-Step Delete Modal */}
      {deleteTargetOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-2xs animate-in fade-in">
          <div
            className="bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-[#E3E3E3]"
            style={{ borderRadius: 'var(--radius-lg)' }}
          >
            <div className="h-12 px-4 bg-[#F1F1F1] border-b border-[#E3E3E3] flex items-center justify-between">
              <h3 className="text-[14px] font-[650] text-[#1A1A1A]">
                Delete Airman Order #{deleteTargetOrder.orderNumber}?
              </h3>
              <button
                onClick={() => setDeleteTargetOrder(null)}
                className="p-1 rounded-md text-[#616161] hover:text-[#1A1A1A]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3 text-[13px]">
              {deleteStep === 1 ? (
                <>
                  <p className="text-[#616161]">
                    Are you sure you want to delete Airman Order{' '}
                    <strong>#{deleteTargetOrder.orderNumber}</strong> (BD:{' '}
                    {deleteTargetOrder.customerBdNumber})?
                  </p>
                  <div className="p-3 bg-[#FAFAFA] rounded-lg border border-[#E3E3E3] text-[12px] text-[#616161]">
                    The order will be moved to <strong>Deleted History</strong> in Settings and can be
                    restored at any time. Subsequent order numbers will shift down by 1.
                  </div>
                </>
              ) : (
                <div className="p-3 bg-[#FEE9E8] rounded-lg border border-[#FCDAD7] text-[#8E0B21] text-[12px] space-y-1">
                  <div className="font-[650] flex items-center space-x-1">
                    <AlertTriangle className="w-4 h-4" />
                    <span>Please Confirm Final Deletion</span>
                  </div>
                  <p>
                    Order #{deleteTargetOrder.orderNumber} will be archived to Deleted History now.
                  </p>
                </div>
              )}
            </div>
            <div className="px-4 py-3 bg-[#FAFAFA] border-t border-[#E3E3E3] flex items-center justify-end space-x-2">
              <button
                onClick={() => setDeleteTargetOrder(null)}
                className="h-7 px-3 rounded-lg bg-white border border-[#E3E3E3] hover:bg-[#F3F3F3] text-[#303030] text-[13px] font-[550]"
              >
                Cancel
              </button>
              {deleteStep === 1 ? (
                <button
                  onClick={handleConfirmDeleteStep1}
                  className="h-7 px-3 rounded-lg bg-[#303030] hover:bg-[#1A1A1A] text-white text-[13px] font-[550]"
                >
                  Continue
                </button>
              ) : (
                <button
                  onClick={handleConfirmDeleteStep2}
                  className="h-7 px-3 rounded-lg bg-[#8E0B21] hover:bg-[#72091A] text-white text-[13px] font-[550]"
                >
                  Confirm Delete
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </PolarisPage>
  );
};
