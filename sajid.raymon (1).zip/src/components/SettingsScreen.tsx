import React, { useState, useMemo, useRef } from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  ItemDefinition,
  WorkItemDefinition,
  AirmanItemDefinition,
  DeletedOfficerOrder,
  DeletedAirmanOrder,
  AppState,
} from '../types/index.ts';
import { PWAInstallButton } from './PWAInstallButton.tsx';
import { formatDate } from '../utils/logic.ts';
import {
  Plus,
  Trash2,
  Edit2,
  Save,
  Check,
  AlertCircle,
  Upload,
  X,
  Smartphone,
  Wifi,
  Sparkles,
  CheckCircle2,
  RotateCcw,
  Search,
  Download,
  Database,
  Archive,
  Layers,
  FileSpreadsheet,
  AlertTriangle,
  History,
  ShieldAlert,
} from 'lucide-react';
import { PolarisPage } from './polaris/PolarisPage.tsx';

export const SettingsScreen: React.FC = () => {
  const {
    state,
    updateSettings,
    addAirmanItem,
    updateAirmanItem,
    deleteAirmanItem,
    addWorkerItem,
    updateWorkerItem,
    deleteWorkerItem,
    addRunningYear,
    restoreOfficerOrder,
    restoreAirmanOrder,
    restoreFullBackup,
  } = useApp();

  const [toastMessage, setToastMessage] = useState('');
  const [toastType, setToastType] = useState<'success' | 'error'>('success');

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(''), 3500);
  };

  // ==========================================
  // 1. Items & Prices (Officer items)
  // ==========================================
  const [officerItemSearch, setOfficerItemSearch] = useState('');
  const [newItemName, setNewItemName] = useState('');
  const [newItemCategory, setNewItemCategory] = useState('Uniform');
  const [newItemPrice, setNewItemPrice] = useState<number>(0);
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [editingItemName, setEditingItemName] = useState('');
  const [editingItemCategory, setEditingItemCategory] = useState('');
  const [editingItemPrice, setEditingItemPrice] = useState<number>(0);

  const itemCategories = useMemo(() => {
    const set = new Set<string>(['Uniform', 'Casual', 'Traditional', 'Accessories']);
    state.settings.items.forEach((it) => {
      if (it.category) set.add(it.category);
    });
    return Array.from(set);
  }, [state.settings.items]);

  const filteredOfficerItems = useMemo(() => {
    if (!officerItemSearch.trim()) return state.settings.items;
    const q = officerItemSearch.toLowerCase().trim();
    return state.settings.items.filter(
      (it) =>
        it.name.toLowerCase().includes(q) ||
        (it.category || '').toLowerCase().includes(q)
    );
  }, [state.settings.items, officerItemSearch]);

  const handleAddOfficerItem = () => {
    if (!newItemName.trim()) {
      showToast('Please enter an item name', 'error');
      return;
    }
    const newItem: ItemDefinition = {
      id: `item-${Date.now()}`,
      name: newItemName.trim(),
      category: newItemCategory.trim() || 'Uniform',
      price: newItemPrice || 0,
      needsPriceCheck: false,
    };
    updateSettings({ items: [...state.settings.items, newItem] });
    setNewItemName('');
    setNewItemPrice(0);
    showToast('Officer item added');
  };

  const handleStartEditOfficerItem = (item: ItemDefinition) => {
    setEditingItemId(item.id);
    setEditingItemName(item.name);
    setEditingItemCategory(item.category || 'Uniform');
    setEditingItemPrice(item.price);
  };

  const handleSaveEditOfficerItem = () => {
    if (!editingItemId || !editingItemName.trim()) return;
    const updated = state.settings.items.map((i) => {
      if (i.id === editingItemId) {
        return {
          ...i,
          name: editingItemName.trim(),
          category: editingItemCategory.trim() || 'Uniform',
          price: editingItemPrice || 0,
          needsPriceCheck: false, // Editing price removes check tag!
        };
      }
      return i;
    });
    updateSettings({ items: updated });
    setEditingItemId(null);
    showToast('Officer item updated');
  };

  const handleDeleteOfficerItem = (id: string) => {
    const updated = state.settings.items.filter((i) => i.id !== id);
    updateSettings({ items: updated });
    showToast('Officer item removed');
  };

  // ==========================================
  // 2. Airman Items (6 items starter)
  // ==========================================
  const [newAirmanItemName, setNewAirmanItemName] = useState('');
  const [editingAirmanItemId, setEditingAirmanItemId] = useState<string | null>(null);
  const [editingAirmanItemName, setEditingAirmanItemName] = useState('');

  const handleAddAirmanItem = () => {
    if (!newAirmanItemName.trim()) return;
    const res = addAirmanItem(newAirmanItemName.trim());
    if (res.success) {
      setNewAirmanItemName('');
      showToast('Airman item added');
    } else {
      showToast(res.error || 'Failed to add', 'error');
    }
  };

  const handleSaveEditAirmanItem = () => {
    if (!editingAirmanItemId || !editingAirmanItemName.trim()) return;
    const res = updateAirmanItem(editingAirmanItemId, editingAirmanItemName.trim());
    if (res.success) {
      setEditingAirmanItemId(null);
      showToast('Airman item renamed');
    } else {
      showToast(res.error || 'Failed to update', 'error');
    }
  };

  // ==========================================
  // 3. Worker Items (51 items starter)
  // ==========================================
  const [workerItemSearch, setWorkerItemSearch] = useState('');
  const [newWorkItemName, setNewWorkItemName] = useState('');
  const [newWorkItemRate, setNewWorkItemRate] = useState<number>(0);
  const [editingWorkItemId, setEditingWorkItemId] = useState<string | null>(null);
  const [editingWorkItemName, setEditingWorkItemName] = useState('');
  const [editingWorkItemRate, setEditingWorkItemRate] = useState<number>(0);

  const filteredWorkerItems = useMemo(() => {
    if (!workerItemSearch.trim()) return state.settings.workItems;
    const q = workerItemSearch.toLowerCase().trim();
    return state.settings.workItems.filter((wi) => wi.name.toLowerCase().includes(q));
  }, [state.settings.workItems, workerItemSearch]);

  const handleAddWorkItem = () => {
    if (!newWorkItemName.trim()) return;
    const res = addWorkerItem(newWorkItemName.trim(), newWorkItemRate || 0);
    if (res.success) {
      setNewWorkItemName('');
      setNewWorkItemRate(0);
      showToast('Worker item added');
    } else {
      showToast(res.error || 'Failed to add', 'error');
    }
  };

  const handleSaveEditWorkItem = () => {
    if (!editingWorkItemId || !editingWorkItemName.trim()) return;
    const res = updateWorkerItem(editingWorkItemId, editingWorkItemName.trim(), editingWorkItemRate || 0);
    if (res.success) {
      setEditingWorkItemId(null);
      showToast('Worker item updated');
    } else {
      showToast(res.error || 'Failed to update', 'error');
    }
  };

  // ==========================================
  // 4 & 5. Discount & Delivery Days
  // ==========================================
  const handleDiscountTypeChange = (type: 'percentage' | 'taka') => {
    updateSettings({ defaultDiscountType: type });
    showToast(`Default discount set to ${type === 'percentage' ? 'Percentage (%)' : 'Fixed Taka (৳)'}`);
  };

  const handleUpcomingDaysChange = (days: number) => {
    if (days >= 1 && days <= 60) {
      updateSettings({ upcomingDeliveryDays: days });
    }
  };

  // ==========================================
  // 6. Invoice Template & Logo
  // ==========================================
  const [invoiceShopName, setInvoiceShopName] = useState(state.settings.invoiceShopName || 'Raymond');
  const [invoiceShopAddress, setInvoiceShopAddress] = useState(state.settings.invoiceShopAddress || '');
  const [invoiceShopPhone, setInvoiceShopPhone] = useState(state.settings.invoiceShopPhone || '');
  const [invoiceTerms, setInvoiceTerms] = useState(state.settings.invoiceTerms || '');

  const handleSaveInvoiceTemplate = () => {
    updateSettings({
      invoiceShopName: invoiceShopName.trim() || 'Raymond',
      invoiceShopAddress: invoiceShopAddress.trim(),
      invoiceShopPhone: invoiceShopPhone.trim(),
      invoiceTerms: invoiceTerms.trim(),
    });
    showToast('Invoice template saved');
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        showToast('Logo file size must be under 2MB', 'error');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        updateSettings({ invoiceLogo: reader.result as string });
        showToast('Shop logo updated');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveLogo = () => {
    updateSettings({ invoiceLogo: '' });
    showToast('Logo removed');
  };

  // ==========================================
  // 7. Print Paper Sizes
  // ==========================================
  const handlePaperSizeChange = (key: 'invoicePaperSize' | 'cuttingSlipPaperSize', size: 'A4' | 'A5') => {
    updateSettings({ [key]: size });
    showToast(`Paper size set to ${size}`);
  };

  // ==========================================
  // 8. Lists (Ribbon, Branch, Trade, Office, Running Years)
  // ==========================================
  const [activeListTab, setActiveListTab] = useState<'ribbon' | 'branch' | 'trade' | 'office' | 'years'>('branch');
  const [newRibbonVal, setNewRibbonVal] = useState('');
  const [newBranchVal, setNewBranchVal] = useState('');
  const [newTradeVal, setNewTradeVal] = useState('');
  const [newOfficeVal, setNewOfficeVal] = useState('');
  const [newRunningYearVal, setNewRunningYearVal] = useState('');

  const addListValue = (key: 'ribbonValues' | 'branchValues' | 'tradeValues' | 'officeValues', val: string) => {
    const trimmed = val.trim();
    if (!trimmed) return;
    const currentList = state.settings[key] || [];
    if (currentList.includes(trimmed)) {
      showToast('Value already exists in list', 'error');
      return;
    }
    updateSettings({ [key]: [...currentList, trimmed] });
    showToast('Item added to list');
  };

  const removeListValue = (key: 'ribbonValues' | 'branchValues' | 'tradeValues' | 'officeValues', idx: number) => {
    const currentList = state.settings[key] || [];
    const updated = currentList.filter((_, i) => i !== idx);
    updateSettings({ [key]: updated });
    showToast('Item removed from list');
  };

  const handleAddRunningYear = () => {
    if (!newRunningYearVal.trim()) return;
    const res = addRunningYear(newRunningYearVal.trim());
    if (res.success) {
      setNewRunningYearVal('');
      showToast(`Running year ${res.normalized} added`);
    } else {
      showToast(res.error || 'Failed to add running year', 'error');
    }
  };

  const removeRunningYear = (yearStr: string) => {
    const updated = state.settings.runningYears.filter((y) => y !== yearStr);
    updateSettings({ runningYears: updated });
    showToast('Running year removed');
  };

  // ==========================================
  // 9. Deleted Orders (Restore UI)
  // ==========================================
  const [deletedCategoryTab, setDeletedCategoryTab] = useState<'Officer' | 'Airman'>('Officer');
  const [deletedSearch, setDeletedSearch] = useState('');
  const [restoreConfirmTarget, setRestoreConfirmTarget] = useState<{
    orderNumber: number;
    category: 'Officer' | 'Airman';
    deletedAt: string;
    customerName: string;
    bdNumber: string;
  } | null>(null);

  const deletedList = useMemo(() => {
    if (deletedCategoryTab === 'Officer') {
      let list = [...state.deletedOfficerOrders].sort(
        (a, b) => new Date(b.deletedAt).getTime() - new Date(a.deletedAt).getTime()
      );
      if (deletedSearch.trim()) {
        const q = deletedSearch.toLowerCase().trim();
        list = list.filter(
          (entry) =>
            String(entry.order.orderNumber).includes(q) ||
            entry.order.customerBdNumber.toLowerCase().includes(q) ||
            entry.order.customerName.toLowerCase().includes(q)
        );
      }
      return list;
    } else {
      let list = [...state.deletedAirmanOrders].sort(
        (a, b) => new Date(b.deletedAt).getTime() - new Date(a.deletedAt).getTime()
      );
      if (deletedSearch.trim()) {
        const q = deletedSearch.toLowerCase().trim();
        list = list.filter(
          (entry) =>
            String(entry.order.orderNumber).includes(q) ||
            entry.order.customerBdNumber.toLowerCase().includes(q) ||
            entry.order.customerName.toLowerCase().includes(q)
        );
      }
      return list;
    }
  }, [state.deletedOfficerOrders, state.deletedAirmanOrders, deletedCategoryTab, deletedSearch]);

  const handleExecuteRestore = () => {
    if (!restoreConfirmTarget) return;
    if (restoreConfirmTarget.category === 'Officer') {
      const res = restoreOfficerOrder(restoreConfirmTarget.deletedAt);
      if (res.success) {
        showToast(`Order #${restoreConfirmTarget.orderNumber} restored successfully`);
      } else {
        showToast(res.error || 'Failed to restore', 'error');
      }
    } else {
      const res = restoreAirmanOrder(restoreConfirmTarget.deletedAt);
      if (res.success) {
        showToast(`Airman order #${restoreConfirmTarget.orderNumber} restored successfully`);
      } else {
        showToast(res.error || 'Failed to restore', 'error');
      }
    }
    setRestoreConfirmTarget(null);
  };

  // ==========================================
  // 10. Data & Backup + Restore
  // ==========================================
  const [lastBackupDate, setLastBackupDate] = useState<string>(() => {
    return localStorage.getItem('raymond_last_backup_date') || 'Never';
  });

  const [restoreModalOpen, setRestoreModalOpen] = useState(false);
  const [restoreCandidateState, setRestoreCandidateState] = useState<AppState | null>(null);
  const [restoreStep, setRestoreStep] = useState<1 | 2>(1);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const downloadJson = (filename: string, data: any) => {
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadFullBackup = () => {
    const now = new Date();
    const dateStr = formatDate(now);
    const filename = `raymond-backup-${dateStr}.json`;
    downloadJson(filename, {
      version: '1.0',
      exportedAt: now.toISOString(),
      app: 'Raymond',
      state: state,
    });
    const recordDate = `${dateStr} ${now.toLocaleTimeString()}`;
    localStorage.setItem('raymond_last_backup_date', recordDate);
    setLastBackupDate(recordDate);
    showToast(`Full backup downloaded: ${filename}`);
  };

  const handleSelectBackupFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);
        const actualState: AppState = parsed.state ? parsed.state : parsed;

        // Basic structural validation
        if (
          !Array.isArray(actualState.officerOrders) ||
          !Array.isArray(actualState.airmanOrders) ||
          !Array.isArray(actualState.customers) ||
          !actualState.settings
        ) {
          throw new Error('Selected file does not have valid Raymond database structure');
        }

        setRestoreCandidateState(actualState);
        setRestoreStep(1);
        setRestoreModalOpen(true);
      } catch (err: any) {
        showToast(err.message || 'Invalid backup JSON file', 'error');
      }
    };
    reader.readAsText(file);
    // Reset input so same file can be chosen again if needed
    e.target.value = '';
  };

  const handleExecuteBackupRestore = async () => {
    if (!restoreCandidateState) return;

    // 1. Automatically download pre-restore safety copy first
    const now = new Date();
    const safetyFilename = `raymond-safety-copy-${formatDate(now)}-${now.getHours()}${now.getMinutes()}${now.getSeconds()}.json`;
    downloadJson(safetyFilename, {
      version: '1.0',
      exportedAt: now.toISOString(),
      type: 'pre-restore-safety-backup',
      app: 'Raymond',
      state: state,
    });

    // 2. Apply restore
    const success = await restoreFullBackup(restoreCandidateState);
    if (success) {
      setRestoreModalOpen(false);
      setRestoreCandidateState(null);
      showToast('Database successfully restored from backup file!');
    } else {
      showToast('Failed to apply restore', 'error');
    }
  };

  const exportCsv = (filename: string, headers: string[], rows: (string | number)[][]) => {
    const csvContent = [headers, ...rows]
      .map((row) =>
        row
          .map((v) => {
            const s = String(v ?? '');
            if (s.includes(',') || s.includes('"') || s.includes('\n')) {
              return `"${s.replace(/"/g, '""')}"`;
            }
            return s;
          })
          .join(',')
      )
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleAdminDownloadAllCsvs = () => {
    const dateStr = formatDate();

    // 1. Officer Orders CSV
    const officerHeaders = [
      'Order #',
      'BD Number',
      'Customer Name',
      'Phone',
      'Branch',
      'Ribbon',
      'Order Date',
      'Delivery Date',
      'Delivered Date',
      'Status',
      'Total Taka',
      'Discount',
      'Advance',
      'Due',
      'Items Count',
    ];
    const officerRows = state.officerOrders.map((o) => [
      o.orderNumber,
      o.customerBdNumber,
      o.customerName,
      o.customerPhone,
      o.branch || '',
      o.ribbon,
      o.orderDate,
      o.deliveryDate,
      o.deliveredDate || '',
      o.status,
      o.totalAmount,
      o.discountAmount || 0,
      o.advance || 0,
      o.due || 0,
      o.items.length,
    ]);
    exportCsv(`raymond-officer-orders-${dateStr}.csv`, officerHeaders, officerRows);

    // 2. Airman Orders CSV
    const airmanHeaders = [
      'Order #',
      'BD Number',
      'Customer Name',
      'Phone',
      'Trade',
      'Ribbon',
      'Office',
      'Running Year',
      'Order Date',
      'Delivered Date',
      'Status',
      'Items Count',
    ];
    const airmanRows = state.airmanOrders.map((o) => [
      o.orderNumber,
      o.customerBdNumber,
      o.customerName,
      o.customerPhone,
      o.trade,
      o.ribbon,
      o.office,
      o.runningYear,
      o.orderDate,
      o.deliveredDate || '',
      o.status,
      o.items.length,
    ]);
    setTimeout(() => {
      exportCsv(`raymond-airman-orders-${dateStr}.csv`, airmanHeaders, airmanRows);
    }, 200);

    // 3. Customers CSV
    const customerHeaders = ['Category', 'BD Number', 'Name', 'Phone', 'Created Date'];
    const customerRows = state.customers.map((c) => [
      c.category,
      c.bdNumber,
      c.name,
      c.phone,
      c.createdAt ? c.createdAt.slice(0, 10) : '',
    ]);
    setTimeout(() => {
      exportCsv(`raymond-customers-${dateStr}.csv`, customerHeaders, customerRows);
    }, 400);

    // 4. Staff Work Entries CSV
    const staffRowHeaders = [
      'Worker ID',
      'Worker Name',
      'Date',
      'Serial',
      'Customer Name',
      'Item',
      'Quantity',
      'Unit Price',
      'Total Taka',
      'Khorach Date',
      'Khorach',
      'Total Payable',
    ];
    const workerMap = new Map(state.workers.map((w) => [w.id, w.name]));
    const staffRowData = state.workerRows.map((r) => [
      r.workerId,
      workerMap.get(r.workerId) || r.workerId,
      r.date,
      r.serial || '',
      r.name || '',
      r.item,
      r.quantity,
      r.unitPrice,
      r.totalTaka,
      r.khorochDate || '',
      r.khoroch || 0,
      (Number(r.totalTaka) || 0) - (Number(r.khoroch) || 0),
    ]);
    setTimeout(() => {
      exportCsv(`raymond-staff-work-entries-${dateStr}.csv`, staffRowHeaders, staffRowData);
    }, 600);

    showToast('Exporting all data tables as CSV files');
  };

  return (
    <PolarisPage
      title="Settings"
      subtitle="Configure catalogue items, worker rates, templates, lists, safety backups, and deleted orders"
    >
      <div className="space-y-6">
        {/* Toast Notification */}
        {toastMessage && (
          <div
            className={`p-3 text-xs font-semibold rounded-lg flex items-center justify-between ${
              toastType === 'success'
                ? 'bg-[#EAFBE7] border border-[#BBE5B3] text-[#108043]'
                : 'bg-[#FBEAE5] border border-[#FED3D1] text-[var(--status-critical)]'
            }`}
          >
            <div className="flex items-center space-x-2">
              {toastType === 'success' ? (
                <Check className="w-4 h-4 text-[#108043]" />
              ) : (
                <AlertCircle className="w-4 h-4 text-[var(--status-critical)]" />
              )}
              <span>{toastMessage}</span>
            </div>
            <button onClick={() => setToastMessage('')} className="p-1 hover:opacity-75">
              ✕
            </button>
          </div>
        )}

      {/* ========================================================= */}
      {/* 1. Items & Prices (Officer Items with Category Grouping)  */}
      {/* ========================================================= */}
      <section className="bg-white rounded-xl border border-gray-200 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-bold text-gray-900 flex items-center space-x-2">
              <span className="w-6 h-6 rounded-md bg-blue-100 text-blue-700 text-xs font-bold flex items-center justify-center">
                1
              </span>
              <span>Items & Prices (Officer Items)</span>
            </h2>
            <p className="text-xs text-gray-500">
              Customer order item catalogue grouped by category. Changing prices here never alters saved orders.
            </p>
          </div>
          <div className="relative w-full sm:w-60">
            <Search className="w-4 h-4 absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search items..."
              value={officerItemSearch}
              onChange={(e) => setOfficerItemSearch(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-gray-50 border border-gray-300 rounded-md focus:bg-white"
            />
          </div>
        </div>

        {/* Add item row */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 p-3.5 bg-gray-50 rounded-lg items-end border border-gray-200">
          <div className="sm:col-span-5">
            <label className="block text-xs font-semibold text-gray-700 mb-1">Item Name</label>
            <input
              type="text"
              value={newItemName}
              onChange={(e) => setNewItemName(e.target.value)}
              placeholder="e.g. BAF Flight Jacket"
              className="w-full px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-md"
            />
          </div>
          <div className="sm:col-span-3">
            <label className="block text-xs font-semibold text-gray-700 mb-1">Category</label>
            <select
              value={newItemCategory}
              onChange={(e) => setNewItemCategory(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs bg-white border border-gray-300 rounded-md"
            >
              {itemCategories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-gray-700 mb-1">Price (৳)</label>
            <input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              value={newItemPrice || ''}
              onChange={(e) => setNewItemPrice(parseInt(e.target.value.replace(/\D/g, '') || '0', 10))}
              placeholder="0"
              className="w-full px-2.5 py-1.5 text-xs bg-white border border-gray-300 rounded-md text-right font-medium"
            />
          </div>
          <div className="sm:col-span-2">
            <button
              onClick={handleAddOfficerItem}
              className="w-full py-1.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-xs font-semibold flex items-center justify-center space-x-1 shadow-2xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Item</span>
            </button>
          </div>
        </div>

        {/* Item list */}
        <div className="max-h-80 overflow-y-auto border border-gray-200 rounded-lg divide-y divide-gray-100 bg-white">
          {filteredOfficerItems.map((item) => {
            const isEditing = editingItemId === item.id;
            if (isEditing) {
              return (
                <div key={item.id} className="p-3 bg-blue-50/60 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <input
                    type="text"
                    value={editingItemName}
                    onChange={(e) => setEditingItemName(e.target.value)}
                    className="flex-1 min-w-[140px] px-2.5 py-1 text-xs border border-gray-300 rounded bg-white"
                  />
                  <select
                    value={editingItemCategory}
                    onChange={(e) => setEditingItemCategory(e.target.value)}
                    className="w-28 px-2 py-1 text-xs border border-gray-300 rounded bg-white"
                  >
                    {itemCategories.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                  <input
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    value={editingItemPrice || ''}
                    onChange={(e) => setEditingItemPrice(parseInt(e.target.value.replace(/\D/g, '') || '0', 10))}
                    className="w-24 px-2.5 py-1 text-xs border border-gray-300 rounded bg-white text-right font-medium"
                  />
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => setEditingItemId(null)}
                      className="p-1 text-gray-500 hover:text-gray-700 rounded"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <button
                      onClick={handleSaveEditOfficerItem}
                      className="p-1 text-emerald-600 hover:text-emerald-800 rounded font-semibold"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            }

            return (
              <div key={item.id} className="p-3 flex items-center justify-between text-xs hover:bg-gray-50">
                <div className="flex items-center space-x-2">
                  <span className="font-semibold text-gray-900">{item.name}</span>
                  {item.category && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-gray-100 text-gray-600">
                      {item.category}
                    </span>
                  )}
                  {item.needsPriceCheck && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                      check price
                    </span>
                  )}
                </div>
                <div className="flex items-center space-x-3">
                  <span className="font-bold text-gray-900">৳{item.price}</span>
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => handleStartEditOfficerItem(item)}
                      className="p-1 text-gray-400 hover:text-blue-600 rounded"
                      title="Edit"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteOfficerItem(item.id)}
                      className="p-1 text-gray-400 hover:text-red-600 rounded"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================= */}
      {/* 2. Airman Items (6 Starter Items)                         */}
      {/* ========================================================= */}
      <section className="bg-white rounded-xl border border-gray-200 p-6 shadow-xs space-y-4">
        <div>
          <h2 className="text-base font-bold text-gray-900 flex items-center space-x-2">
            <span className="w-6 h-6 rounded-md bg-indigo-100 text-indigo-700 text-xs font-bold flex items-center justify-center">
              2
            </span>
            <span>Airman Items</span>
          </h2>
          <p className="text-xs text-gray-500">
            Dedicated items offered on Airman bulk batch orders. Airman orders display no prices.
          </p>
        </div>

        {/* Add Airman item row */}
        <div className="flex space-x-2 p-3 bg-gray-50 rounded-lg border border-gray-200">
          <input
            type="text"
            value={newAirmanItemName}
            onChange={(e) => setNewAirmanItemName(e.target.value)}
            placeholder="New Airman item name..."
            className="flex-1 px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-md"
          />
          <button
            onClick={handleAddAirmanItem}
            className="py-1.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-xs font-semibold flex items-center space-x-1 shadow-2xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Item</span>
          </button>
        </div>

        {/* List of Airman Items */}
        <div className="border border-gray-200 rounded-lg divide-y divide-gray-100 bg-white">
          {(state.settings.airmanItems || []).map((ai: AirmanItemDefinition) => {
            const isEditing = editingAirmanItemId === ai.id;
            if (isEditing) {
              return (
                <div key={ai.id} className="p-3 bg-indigo-50/60 flex items-center justify-between gap-2 text-xs">
                  <input
                    type="text"
                    value={editingAirmanItemName}
                    onChange={(e) => setEditingAirmanItemName(e.target.value)}
                    className="flex-1 px-2.5 py-1 text-xs border border-gray-300 rounded bg-white"
                  />
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => setEditingAirmanItemId(null)}
                      className="p-1 text-gray-500 hover:text-gray-700"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <button
                      onClick={handleSaveEditAirmanItem}
                      className="p-1 text-indigo-600 hover:text-indigo-800"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            }

            return (
              <div key={ai.id} className="p-3 flex items-center justify-between text-xs hover:bg-gray-50">
                <span className="font-semibold text-gray-900">{ai.name}</span>
                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => {
                      setEditingAirmanItemId(ai.id);
                      setEditingAirmanItemName(ai.name);
                    }}
                    className="p-1 text-gray-400 hover:text-blue-600 rounded"
                    title="Rename"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      const res = deleteAirmanItem(ai.id);
                      if (res.success) showToast('Airman item removed');
                      else showToast(res.error || 'Failed to remove', 'error');
                    }}
                    className="p-1 text-gray-400 hover:text-red-600 rounded"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================= */}
      {/* 3. Worker Items (51 Starter Items from Table 4.3)         */}
      {/* ========================================================= */}
      <section className="bg-white rounded-xl border border-gray-200 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-bold text-gray-900 flex items-center space-x-2">
              <span className="w-6 h-6 rounded-md bg-amber-100 text-amber-700 text-xs font-bold flex items-center justify-center">
                3
              </span>
              <span>Worker Items (Tailor Labor Rates)</span>
            </h2>
            <p className="text-xs text-gray-500">
              Rates paid to tailors per piece. Separate from customer order prices; editing here never alters saved entries.
            </p>
          </div>
          <div className="relative w-full sm:w-60">
            <Search className="w-4 h-4 absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search worker rates..."
              value={workerItemSearch}
              onChange={(e) => setWorkerItemSearch(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-gray-50 border border-gray-300 rounded-md focus:bg-white"
            />
          </div>
        </div>

        {/* Add worker item row */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 p-3.5 bg-gray-50 rounded-lg items-end border border-gray-200">
          <div className="sm:col-span-7">
            <label className="block text-xs font-semibold text-gray-700 mb-1">Item / Stitching Task</label>
            <input
              type="text"
              value={newWorkItemName}
              onChange={(e) => setNewWorkItemName(e.target.value)}
              placeholder="e.g. Officer Shirt Stitching"
              className="w-full px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-md"
            />
          </div>
          <div className="sm:col-span-3">
            <label className="block text-xs font-semibold text-gray-700 mb-1">Worker Rate (৳)</label>
            <input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              value={newWorkItemRate || ''}
              onChange={(e) => setNewWorkItemRate(parseInt(e.target.value.replace(/\D/g, '') || '0', 10))}
              placeholder="0"
              className="w-full px-2.5 py-1.5 text-xs bg-white border border-gray-300 rounded-md text-right font-medium"
            />
          </div>
          <div className="sm:col-span-2">
            <button
              onClick={handleAddWorkItem}
              className="w-full py-1.5 px-3 bg-amber-600 hover:bg-amber-700 text-white rounded-md text-xs font-semibold flex items-center justify-center space-x-1 shadow-2xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Rate</span>
            </button>
          </div>
        </div>

        {/* Worker items list */}
        <div className="max-h-80 overflow-y-auto border border-gray-200 rounded-lg divide-y divide-gray-100 bg-white">
          {filteredWorkerItems.map((wi: WorkItemDefinition) => {
            const isEditing = editingWorkItemId === wi.id;
            if (isEditing) {
              return (
                <div key={wi.id} className="p-3 bg-amber-50/60 flex items-center justify-between gap-2 text-xs">
                  <input
                    type="text"
                    value={editingWorkItemName}
                    onChange={(e) => setEditingWorkItemName(e.target.value)}
                    className="flex-1 px-2.5 py-1 text-xs border border-gray-300 rounded bg-white"
                  />
                  <input
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    value={editingWorkItemRate || ''}
                    onChange={(e) => setNewWorkItemRate(parseInt(e.target.value.replace(/\D/g, '') || '0', 10))}
                    className="w-24 px-2.5 py-1 text-xs border border-gray-300 rounded bg-white text-right font-medium"
                  />
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => setEditingWorkItemId(null)}
                      className="p-1 text-gray-500 hover:text-gray-700"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <button onClick={handleSaveEditWorkItem} className="p-1 text-amber-600 hover:text-amber-800">
                      <Check className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            }

            return (
              <div key={wi.id} className="p-3 flex items-center justify-between text-xs hover:bg-gray-50">
                <div className="flex items-center space-x-2">
                  <span className="font-semibold text-gray-900">{wi.name}</span>
                  {wi.flaggedCheck && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                      check
                    </span>
                  )}
                </div>
                <div className="flex items-center space-x-3">
                  <span className="font-bold text-gray-900">৳{wi.rate}</span>
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => {
                        setEditingWorkItemId(wi.id);
                        setEditingWorkItemName(wi.name);
                        setEditingWorkItemRate(wi.rate);
                      }}
                      className="p-1 text-gray-400 hover:text-blue-600 rounded"
                      title="Edit"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        const res = deleteWorkerItem(wi.id);
                        if (res.success) showToast('Worker item removed');
                        else showToast(res.error || 'Failed to remove', 'error');
                      }}
                      className="p-1 text-gray-400 hover:text-red-600 rounded"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================= */}
      {/* 4 & 5. Discount Type & Upcoming Delivery Days             */}
      {/* ========================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* 4. Default discount type */}
        <section className="bg-white rounded-xl border border-gray-200 p-6 shadow-xs space-y-4">
          <div>
            <h2 className="text-base font-bold text-gray-900 flex items-center space-x-2">
              <span className="w-6 h-6 rounded-md bg-purple-100 text-purple-700 text-xs font-bold flex items-center justify-center">
                4
              </span>
              <span>Default Discount Type</span>
            </h2>
            <p className="text-xs text-gray-500">
              When entering a plain number in the discount field on new Officer orders.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              onClick={() => handleDiscountTypeChange('percentage')}
              className={`p-3 text-xs font-semibold rounded-lg border text-left transition-all ${
                state.settings.defaultDiscountType === 'percentage'
                  ? 'border-blue-600 bg-blue-50 text-blue-900 ring-2 ring-blue-500'
                  : 'border-gray-200 hover:bg-gray-50 text-gray-700'
              }`}
            >
              <div className="font-bold text-sm mb-0.5">Percentage (%)</div>
              <div className="text-[11px] text-gray-500">Entering 10 calculates 10% discount</div>
            </button>

            <button
              onClick={() => handleDiscountTypeChange('taka')}
              className={`p-3 text-xs font-semibold rounded-lg border text-left transition-all ${
                state.settings.defaultDiscountType === 'taka'
                  ? 'border-blue-600 bg-blue-50 text-blue-900 ring-2 ring-blue-500'
                  : 'border-gray-200 hover:bg-gray-50 text-gray-700'
              }`}
            >
              <div className="font-bold text-sm mb-0.5">Fixed Taka (৳)</div>
              <div className="text-[11px] text-gray-500">Entering 100 deducts ৳100 directly</div>
            </button>
          </div>
        </section>

        {/* 5. Upcoming delivery days */}
        <section className="bg-white rounded-xl border border-gray-200 p-6 shadow-xs space-y-4">
          <div>
            <h2 className="text-base font-bold text-gray-900 flex items-center space-x-2">
              <span className="w-6 h-6 rounded-md bg-teal-100 text-teal-700 text-xs font-bold flex items-center justify-center">
                5
              </span>
              <span>Upcoming Delivery Window</span>
            </h2>
            <p className="text-xs text-gray-500">
              Orders due within this number of days are highlighted in the Upcoming card.
            </p>
          </div>

          <div className="flex items-center space-x-3 pt-2">
            <input
              type="number"
              min="1"
              max="60"
              value={state.settings.upcomingDeliveryDays || 3}
              onChange={(e) => handleUpcomingDaysChange(parseInt(e.target.value) || 3)}
              className="w-24 px-3 py-2 text-sm bg-white border border-gray-300 rounded-lg text-center font-bold"
            />
            <span className="text-xs font-semibold text-gray-700">Days ahead</span>
          </div>
        </section>
      </div>

      {/* ========================================================= */}
      {/* 6. Invoice Template (Shop Name, Address, Phone, Logo)     */}
      {/* ========================================================= */}
      <section className="bg-white rounded-xl border border-gray-200 p-6 shadow-xs space-y-4">
        <div>
          <h2 className="text-base font-bold text-gray-900 flex items-center space-x-2">
            <span className="w-6 h-6 rounded-md bg-blue-100 text-blue-700 text-xs font-bold flex items-center justify-center">
              6
            </span>
            <span>Invoice Template & Branding</span>
          </h2>
          <p className="text-xs text-gray-500">
            Printed at the top of customer invoices and cutting slips.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">Shop Name</label>
            <input
              type="text"
              value={invoiceShopName}
              onChange={(e) => setInvoiceShopName(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-md font-medium"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">Phone Number</label>
            <input
              type="text"
              value={invoiceShopPhone}
              onChange={(e) => setInvoiceShopPhone(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-md font-medium"
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-xs font-semibold text-gray-700 mb-1">Shop Address</label>
            <input
              type="text"
              value={invoiceShopAddress}
              onChange={(e) => setInvoiceShopAddress(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-md"
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-xs font-semibold text-gray-700 mb-1">Invoice Terms & Policy</label>
            <textarea
              rows={2}
              value={invoiceTerms}
              onChange={(e) => setInvoiceTerms(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-md"
            />
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2 border-t border-gray-100">
          <div className="flex items-center space-x-3">
            {state.settings.invoiceLogo ? (
              <div className="relative group">
                <img
                  src={state.settings.invoiceLogo}
                  alt="Invoice Logo"
                  className="w-12 h-12 object-contain rounded border border-gray-200 bg-white p-1"
                />
                <button
                  onClick={handleRemoveLogo}
                  className="absolute -top-1.5 -right-1.5 bg-red-600 text-white rounded-full p-0.5 hover:bg-red-700 shadow-2xs"
                  title="Remove logo"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ) : (
              <div className="w-12 h-12 rounded border border-dashed border-gray-300 flex items-center justify-center text-gray-400 bg-gray-50">
                <Upload className="w-4 h-4" />
              </div>
            )}
            <div>
              <label className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-md text-xs font-semibold cursor-pointer">
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Logo</span>
                <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
              </label>
              <p className="text-[10px] text-gray-400 mt-0.5">PNG or SVG, max 2MB</p>
            </div>
          </div>

          <button
            onClick={handleSaveInvoiceTemplate}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-xs font-semibold flex items-center justify-center space-x-1.5 shadow-2xs"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Template</span>
          </button>
        </div>
      </section>

      {/* ========================================================= */}
      {/* 7. Print Paper Size (Invoice & Cutting Slip: A4 / A5)     */}
      {/* ========================================================= */}
      <section className="bg-white rounded-xl border border-gray-200 p-6 shadow-xs space-y-4">
        <div>
          <h2 className="text-base font-bold text-gray-900 flex items-center space-x-2">
            <span className="w-6 h-6 rounded-md bg-emerald-100 text-emerald-700 text-xs font-bold flex items-center justify-center">
              7
            </span>
            <span>Print Paper Sizes</span>
          </h2>
          <p className="text-xs text-gray-500">
            Default paper format for customer invoice vouchers and cutting master slips.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
          <div className="p-3.5 bg-gray-50 rounded-lg border border-gray-200 space-y-2">
            <span className="block text-xs font-semibold text-gray-800">Customer Invoice Paper Size</span>
            <div className="flex space-x-2">
              {(['A4', 'A5'] as const).map((size) => (
                <button
                  key={size}
                  onClick={() => handlePaperSizeChange('invoicePaperSize', size)}
                  className={`flex-1 py-1.5 rounded-md text-xs font-bold transition-all ${
                    (state.settings.invoicePaperSize || 'A4') === size
                      ? 'bg-blue-600 text-white shadow-2xs'
                      : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          <div className="p-3.5 bg-gray-50 rounded-lg border border-gray-200 space-y-2">
            <span className="block text-xs font-semibold text-gray-800">Cutting Slip Paper Size</span>
            <div className="flex space-x-2">
              {(['A4', 'A5'] as const).map((size) => (
                <button
                  key={size}
                  onClick={() => handlePaperSizeChange('cuttingSlipPaperSize', size)}
                  className={`flex-1 py-1.5 rounded-md text-xs font-bold transition-all ${
                    (state.settings.cuttingSlipPaperSize || 'A5') === size
                      ? 'bg-blue-600 text-white shadow-2xs'
                      : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================= */}
      {/* 8. Lists (Ribbon, Branch, Trade, Office, Running Years)   */}
      {/* ========================================================= */}
      <section className="bg-white rounded-xl border border-gray-200 p-6 shadow-xs space-y-4">
        <div>
          <h2 className="text-base font-bold text-gray-900 flex items-center space-x-2">
            <span className="w-6 h-6 rounded-md bg-blue-100 text-blue-700 text-xs font-bold flex items-center justify-center">
              8
            </span>
            <span>Dropdown Lists</span>
          </h2>
          <p className="text-xs text-gray-500">
            Standard values for form selectors across Officer and Airman orders.
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex space-x-1.5 border-b border-gray-200 pb-2 overflow-x-auto">
          {[
            { id: 'branch', label: 'Branch (GDP/NON-GDP)' },
            { id: 'ribbon', label: 'Ribbon (1–20)' },
            { id: 'years', label: 'Running Years' },
            { id: 'trade', label: 'Airman Trade' },
            { id: 'office', label: 'Airman Office' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveListTab(tab.id as any)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                activeListTab === tab.id
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* 8a. Branch */}
        {activeListTab === 'branch' && (
          <div className="space-y-3">
            <div className="flex space-x-2">
              <input
                type="text"
                value={newBranchVal}
                onChange={(e) => setNewBranchVal(e.target.value)}
                placeholder="New Branch (e.g. GDP, NON-GDP, HALF WING)"
                className="flex-1 px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-md"
              />
              <button
                onClick={() => {
                  addListValue('branchValues', newBranchVal);
                  setNewBranchVal('');
                }}
                className="px-3 py-1.5 bg-blue-600 text-white rounded-md text-xs font-semibold flex items-center space-x-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {(state.settings.branchValues || ['GDP', 'NON-GDP', 'HALF WING']).map((v, i) => (
                <div key={i} className="flex justify-between items-center text-xs bg-gray-50 px-3 py-2 rounded-md border border-gray-200">
                  <span className="font-semibold text-gray-900">{v}</span>
                  <button onClick={() => removeListValue('branchValues', i)} className="text-gray-400 hover:text-red-600">
                    ✕
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 8b. Ribbon */}
        {activeListTab === 'ribbon' && (
          <div className="space-y-3">
            <div className="flex space-x-2">
              <input
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                value={newRibbonVal}
                onChange={(e) => setNewRibbonVal(e.target.value.replace(/\D/g, ''))}
                placeholder="New Ribbon number..."
                className="flex-1 px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-md"
              />
              <button
                onClick={() => {
                  addListValue('ribbonValues', newRibbonVal);
                  setNewRibbonVal('');
                }}
                className="px-3 py-1.5 bg-blue-600 text-white rounded-md text-xs font-semibold flex items-center space-x-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>
            <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2">
              {state.settings.ribbonValues.map((v, i) => (
                <div key={i} className="flex justify-between items-center text-xs bg-gray-50 px-2.5 py-1.5 rounded-md border border-gray-200">
                  <span className="font-bold text-gray-900">{v}</span>
                  <button onClick={() => removeListValue('ribbonValues', i)} className="text-gray-400 hover:text-red-600 ml-1">
                    ✕
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 8c. Running Years */}
        {activeListTab === 'years' && (
          <div className="space-y-3">
            <div className="flex space-x-2">
              <input
                type="text"
                value={newRunningYearVal}
                onChange={(e) => setNewRunningYearVal(e.target.value)}
                placeholder="e.g. 2030–2031 (consecutive years)"
                className="flex-1 px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-md"
              />
              <button
                onClick={handleAddRunningYear}
                className="px-3 py-1.5 bg-blue-600 text-white rounded-md text-xs font-semibold flex items-center space-x-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Year</span>
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {state.settings.runningYears.map((yr) => (
                <div key={yr} className="flex justify-between items-center text-xs bg-gray-50 px-3 py-2 rounded-md border border-gray-200">
                  <span className="font-semibold text-gray-900">{yr}</span>
                  <button onClick={() => removeRunningYear(yr)} className="text-gray-400 hover:text-red-600">
                    ✕
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 8d. Airman Trade */}
        {activeListTab === 'trade' && (
          <div className="space-y-3">
            <div className="flex space-x-2">
              <input
                type="text"
                value={newTradeVal}
                onChange={(e) => setNewTradeVal(e.target.value)}
                placeholder="Trade (e.g. A/F Tech, Admin, Medical)"
                className="flex-1 px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-md"
              />
              <button
                onClick={() => {
                  addListValue('tradeValues', newTradeVal);
                  setNewTradeVal('');
                }}
                className="px-3 py-1.5 bg-blue-600 text-white rounded-md text-xs font-semibold flex items-center space-x-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {state.settings.tradeValues.map((v, i) => (
                <div key={i} className="flex justify-between items-center text-xs bg-gray-50 px-3 py-2 rounded-md border border-gray-200">
                  <span className="font-medium text-gray-900">{v}</span>
                  <button onClick={() => removeListValue('tradeValues', i)} className="text-gray-400 hover:text-red-600">
                    ✕
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 8e. Airman Office */}
        {activeListTab === 'office' && (
          <div className="space-y-3">
            <div className="flex space-x-2">
              <input
                type="text"
                value={newOfficeVal}
                onChange={(e) => setNewOfficeVal(e.target.value)}
                placeholder="Office (e.g. Admin Wing, Flying Wing)"
                className="flex-1 px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-md"
              />
              <button
                onClick={() => {
                  addListValue('officeValues', newOfficeVal);
                  setNewOfficeVal('');
                }}
                className="px-3 py-1.5 bg-blue-600 text-white rounded-md text-xs font-semibold flex items-center space-x-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {state.settings.officeValues.map((v, i) => (
                <div key={i} className="flex justify-between items-center text-xs bg-gray-50 px-3 py-2 rounded-md border border-gray-200">
                  <span className="font-medium text-gray-900">{v}</span>
                  <button onClick={() => removeListValue('officeValues', i)} className="text-gray-400 hover:text-red-600">
                    ✕
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* ========================================================= */}
      {/* 9. Deleted Orders (Restore UI - FIX-07)                    */}
      {/* ========================================================= */}
      <section className="bg-white rounded-xl border border-gray-200 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-gray-900 flex items-center space-x-2">
              <span className="w-6 h-6 rounded-md bg-rose-100 text-rose-700 text-xs font-bold flex items-center justify-center">
                9
              </span>
              <span>Deleted Orders History</span>
            </h2>
            <p className="text-xs text-gray-500">
              Orders deleted by mistake can be restored with original number #N (later orders shift up automatically).
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <div className="flex bg-gray-100 p-0.5 rounded-lg text-xs font-semibold">
              <button
                onClick={() => setDeletedCategoryTab('Officer')}
                className={`px-3 py-1 rounded-md transition-colors ${
                  deletedCategoryTab === 'Officer' ? 'bg-white text-gray-900 shadow-2xs' : 'text-gray-600'
                }`}
              >
                Officer ({state.deletedOfficerOrders.length})
              </button>
              <button
                onClick={() => setDeletedCategoryTab('Airman')}
                className={`px-3 py-1 rounded-md transition-colors ${
                  deletedCategoryTab === 'Airman' ? 'bg-white text-gray-900 shadow-2xs' : 'text-gray-600'
                }`}
              >
                Airman ({state.deletedAirmanOrders.length})
              </button>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="relative w-full">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search deleted orders by #, BD, or name..."
            value={deletedSearch}
            onChange={(e) => setDeletedSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-gray-50 border border-gray-300 rounded-md focus:bg-white"
          />
        </div>

        {/* List of deleted orders */}
        {deletedList.length === 0 ? (
          <div className="p-8 text-center border border-dashed border-gray-300 rounded-lg text-gray-400 text-xs">
            <History className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <span>No deleted {deletedCategoryTab} orders recorded</span>
          </div>
        ) : (
          <div className="border border-gray-200 rounded-lg divide-y divide-gray-100 max-h-80 overflow-y-auto bg-white">
            {deletedList.map((entry) => {
              const isOfficer = 'totalAmount' in entry.order;
              const order = entry.order;
              return (
                <div
                  key={entry.deletedAt}
                  className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs hover:bg-gray-50"
                >
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-gray-900 text-sm">#{order.orderNumber}</span>
                      <span
                        className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                          isOfficer ? 'bg-blue-50 text-blue-700' : 'bg-indigo-50 text-indigo-700'
                        }`}
                      >
                        {isOfficer ? 'Officer' : 'Airman'}
                      </span>
                      <span className="text-gray-400">·</span>
                      <span className="font-semibold text-gray-900">{order.customerName}</span>
                      <span className="text-gray-500">BD: {order.customerBdNumber}</span>
                    </div>
                    <div className="text-[11px] text-gray-500 flex flex-wrap items-center gap-x-3">
                      <span>Deleted: {entry.deletedAt.slice(0, 16).replace('T', ' ')}</span>
                      <span>Status when deleted: <span className="font-medium text-gray-700">{order.status}</span></span>
                      {isOfficer && <span>Total: <span className="font-medium text-gray-900">৳{(order as any).totalAmount}</span></span>}
                    </div>
                  </div>

                  <button
                    onClick={() =>
                      setRestoreConfirmTarget({
                        orderNumber: order.orderNumber,
                        category: isOfficer ? 'Officer' : 'Airman',
                        deletedAt: entry.deletedAt,
                        customerName: order.customerName,
                        bdNumber: order.customerBdNumber,
                      })
                    }
                    className="inline-flex items-center justify-center space-x-1.5 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-md font-semibold text-xs transition-colors self-start sm:self-auto"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Restore #{order.orderNumber}</span>
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* ========================================================= */}
      {/* 10. Data & Backup (Download, Restore, Admin CSV - FIX-09) */}
      {/* ========================================================= */}
      <section className="bg-white rounded-xl border border-gray-200 p-6 shadow-xs space-y-5">
        <div>
          <h2 className="text-base font-bold text-gray-900 flex items-center space-x-2">
            <span className="w-6 h-6 rounded-md bg-blue-100 text-blue-700 text-xs font-bold flex items-center justify-center">
              10
            </span>
            <span>Data, Backups & Safety Snapshot</span>
          </h2>
          <p className="text-xs text-gray-500">
            Export a full JSON snapshot of all orders, workers, and settings, or export full data tables as CSV.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Download JSON Backup */}
          <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/40 flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center space-x-2 text-blue-900 font-bold text-sm">
                <Database className="w-4 h-4 text-blue-600" />
                <span>Full JSON Backup</span>
              </div>
              <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                Single file containing everything: active orders, deleted history, customer measurements, staff sheets, and settings.
              </p>
              <div className="text-[11px] text-gray-500 mt-2">
                Last backup: <span className="font-semibold text-gray-700">{lastBackupDate}</span>
              </div>
            </div>
            <button
              onClick={handleDownloadFullBackup}
              className="w-full py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-xs font-semibold flex items-center justify-center space-x-1.5 shadow-2xs"
            >
              <Download className="w-4 h-4" />
              <span>Download Backup (.json)</span>
            </button>
          </div>

          {/* Restore JSON Backup */}
          <div className="p-4 rounded-xl border border-purple-200 bg-purple-50/40 flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center space-x-2 text-purple-900 font-bold text-sm">
                <Archive className="w-4 h-4 text-purple-600" />
                <span>Restore Database</span>
              </div>
              <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                Select a previous Raymond backup file to restore. A safety copy of your current data is saved automatically before applying.
              </p>
            </div>
            <div>
              <input
                type="file"
                ref={fileInputRef}
                accept=".json,application/json"
                onChange={handleSelectBackupFile}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-2 px-3 bg-purple-600 hover:bg-purple-700 text-white rounded-md text-xs font-semibold flex items-center justify-center space-x-1.5 shadow-2xs"
              >
                <Upload className="w-4 h-4" />
                <span>Restore From Backup</span>
              </button>
            </div>
          </div>

          {/* Admin Export All CSVs */}
          <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/40 flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center space-x-2 text-emerald-900 font-bold text-sm">
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                <span>Export All Tables (Admin)</span>
              </div>
              <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                Downloads separate CSV spreadsheets for Officer orders, Airman orders, Customers, and Staff work sheets.
              </p>
            </div>
            <button
              onClick={handleAdminDownloadAllCsvs}
              className="w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-xs font-semibold flex items-center justify-center space-x-1.5 shadow-2xs"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Download All CSVs</span>
            </button>
          </div>
        </div>
      </section>

      {/* ========================================================= */}
      {/* 11. Install app (PWA)                                     */}
      {/* ========================================================= */}
      <section className="bg-white rounded-xl border border-gray-200 p-6 shadow-xs space-y-4">
        <div>
          <h2 className="text-base font-bold text-gray-900 flex items-center space-x-2">
            <span className="w-6 h-6 rounded-md bg-blue-100 text-blue-700 text-xs font-bold flex items-center justify-center">
              11
            </span>
            <span>Install App (PWA)</span>
          </h2>
          <p className="text-xs text-gray-500">
            Install Raymond directly on your phone, tablet, or desktop for fast standalone access and offline resilience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
          <div className="p-4 rounded-xl border border-blue-100 bg-blue-50/50 space-y-2">
            <div className="flex items-center space-x-2 text-blue-800 font-semibold text-sm">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span>Full Screen Experience</span>
            </div>
            <p className="text-xs text-blue-900/80 leading-relaxed">
              Runs as a standalone desktop and mobile application without URL bars or browser navigation clutter.
            </p>
          </div>

          <div className="p-4 rounded-xl border border-emerald-100 bg-emerald-50/50 space-y-2">
            <div className="flex items-center space-x-2 text-emerald-800 font-semibold text-sm">
              <Wifi className="w-4 h-4 text-emerald-600" />
              <span>Offline Resilience</span>
            </div>
            <p className="text-xs text-emerald-900/80 leading-relaxed">
              Cached application shell and Google fonts allow shop workflow to open and operate even during brief network drops.
            </p>
          </div>

          <div className="p-4 rounded-xl border border-amber-100 bg-amber-50/50 space-y-2">
            <div className="flex items-center space-x-2 text-amber-800 font-semibold text-sm">
              <CheckCircle2 className="w-4 h-4 text-amber-600" />
              <span>Instant Launch</span>
            </div>
            <p className="text-xs text-amber-900/80 leading-relaxed">
              Pinned directly on your home screen or dock. Works on Android, iOS Safari, Chrome, Edge, and macOS.
            </p>
          </div>
        </div>

        <div className="pt-2">
          <PWAInstallButton variant="settings" />
        </div>
      </section>

      {/* ========================================================= */}
      {/* Modal: Restore Order Confirmation (FIX-07)                */}
      {/* ========================================================= */}
      {restoreConfirmTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-gray-200 space-y-4">
            <div className="flex items-center space-x-3 text-blue-600">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                <RotateCcw className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 text-base">
                  Restore {restoreConfirmTarget.category} Order #{restoreConfirmTarget.orderNumber}
                </h3>
                <p className="text-xs text-gray-500">
                  {restoreConfirmTarget.customerName} (BD: {restoreConfirmTarget.bdNumber})
                </p>
              </div>
            </div>

            <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-900 leading-relaxed space-y-1">
              <div className="font-semibold flex items-center space-x-1">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <span>Notice on Order Renumbering</span>
              </div>
              <p>
                Restoring this order will bring it back as <strong>#{restoreConfirmTarget.orderNumber}</strong>.
                All active {restoreConfirmTarget.category} orders with number #{restoreConfirmTarget.orderNumber} or
                higher will shift up by 1.
              </p>
            </div>

            <div className="flex items-center justify-end space-x-2.5 pt-2">
              <button
                onClick={() => setRestoreConfirmTarget(null)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-xs font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleExecuteRestore}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs"
              >
                Confirm Restore
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* Modal: Full Backup Restore Preview & Confirmation         */}
      {/* ========================================================= */}
      {restoreModalOpen && restoreCandidateState && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-xl max-w-lg w-full p-6 shadow-xl border border-gray-200 space-y-4">
            <div className="flex items-center space-x-3 text-purple-600">
              <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                <ShieldAlert className="w-5 h-5 text-purple-700" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 text-base">Restore Database From Backup</h3>
                <p className="text-xs text-gray-500">
                  Step {restoreStep} of 2 · Inspect contents before replacing current database
                </p>
              </div>
            </div>

            {/* Candidate Content Stats */}
            <div className="p-4 bg-gray-50 rounded-lg border border-gray-200 space-y-3">
              <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider">
                Backup File Contents
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div className="bg-white p-2.5 rounded border border-gray-200">
                  <span className="text-gray-400 block text-[10px]">Officer Orders</span>
                  <span className="text-base font-bold text-gray-900">
                    {restoreCandidateState.officerOrders?.length || 0}
                  </span>
                </div>
                <div className="bg-white p-2.5 rounded border border-gray-200">
                  <span className="text-gray-400 block text-[10px]">Airman Orders</span>
                  <span className="text-base font-bold text-gray-900">
                    {restoreCandidateState.airmanOrders?.length || 0}
                  </span>
                </div>
                <div className="bg-white p-2.5 rounded border border-gray-200">
                  <span className="text-gray-400 block text-[10px]">Customers</span>
                  <span className="text-base font-bold text-gray-900">
                    {restoreCandidateState.customers?.length || 0}
                  </span>
                </div>
                <div className="bg-white p-2.5 rounded border border-gray-200">
                  <span className="text-gray-400 block text-[10px]">Staff Workers</span>
                  <span className="text-base font-bold text-gray-900">
                    {restoreCandidateState.workers?.length || 0}
                  </span>
                </div>
                <div className="bg-white p-2.5 rounded border border-gray-200">
                  <span className="text-gray-400 block text-[10px]">Work Entries</span>
                  <span className="text-base font-bold text-gray-900">
                    {restoreCandidateState.workerRows?.length || 0}
                  </span>
                </div>
                <div className="bg-white p-2.5 rounded border border-gray-200">
                  <span className="text-gray-400 block text-[10px]">Deleted Orders</span>
                  <span className="text-base font-bold text-gray-900">
                    {(restoreCandidateState.deletedOfficerOrders?.length || 0) +
                      (restoreCandidateState.deletedAirmanOrders?.length || 0)}
                  </span>
                </div>
              </div>
            </div>

            {restoreStep === 1 ? (
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200 text-xs text-blue-900 leading-relaxed">
                Click <strong>Next</strong> to proceed. A safety download copy of your current active data will be saved
                automatically before any changes are applied.
              </div>
            ) : (
              <div className="p-3 bg-red-50 rounded-lg border border-red-200 text-xs text-red-900 leading-relaxed space-y-1">
                <div className="font-bold flex items-center space-x-1">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  <span>Final Warning</span>
                </div>
                <p>
                  This action will replace all current database records with the contents of this file. Current records
                  will be archived in an automatic safety download.
                </p>
              </div>
            )}

            <div className="flex items-center justify-end space-x-2.5 pt-2">
              <button
                onClick={() => {
                  setRestoreModalOpen(false);
                  setRestoreCandidateState(null);
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg text-xs font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              {restoreStep === 1 ? (
                <button
                  onClick={() => setRestoreStep(2)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs"
                >
                  Next Step
                </button>
              ) : (
                <button
                  onClick={handleExecuteBackupRestore}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-semibold shadow-xs"
                >
                  Download Safety Copy & Restore
                </button>
              )}
            </div>
          </div>
        </div>
      )}
      </div>
    </PolarisPage>
  );
};
