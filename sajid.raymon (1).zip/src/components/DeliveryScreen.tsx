import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { ArrowLeft, Search, Truck, Check, X, Phone, User, Calendar } from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { PolarisTabs } from './polaris/PolarisTabs.tsx';
import { PolarisBadge } from './polaris/PolarisBadge.tsx';

interface DeliveryScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const DeliveryScreen: React.FC<DeliveryScreenProps> = ({ onNavigate }) => {
  const { state, updateOfficerOrderStatus, updateAirmanOrderStatus } = useApp();

  const [activeTab, setActiveTab] = useState<'Officer' | 'Airman'>('Officer');
  const [searchQuery, setSearchQuery] = useState('');
  const [toastMessage, setToastMessage] = useState('');

  // Undelivered Officer Orders
  const undeliveredOfficerOrders = useMemo(() => {
    return state.officerOrders.filter((o) => o.status !== 'Delivered');
  }, [state.officerOrders]);

  // Undelivered Airman Orders
  const undeliveredAirmanOrders = useMemo(() => {
    return state.airmanOrders.filter((o) => o.status !== 'Delivered');
  }, [state.airmanOrders]);

  const currentList = activeTab === 'Officer' ? undeliveredOfficerOrders : undeliveredAirmanOrders;

  const filteredOrders = useMemo(() => {
    if (!searchQuery.trim()) return currentList;
    const q = searchQuery.toLowerCase().trim();
    return currentList.filter((order) => {
      const name = (order.customerName || '').toLowerCase();
      const phone = (order.customerPhone || '').toLowerCase();
      const bd = order.customerBdNumber.toLowerCase();
      const num = String(order.orderNumber);
      return name.includes(q) || phone.includes(q) || bd.includes(q) || num.includes(q);
    });
  }, [currentList, searchQuery]);

  const handleDeliver = (orderNumber: number) => {
    if (activeTab === 'Officer') {
      updateOfficerOrderStatus(orderNumber, 'Delivered');
    } else {
      updateAirmanOrderStatus(orderNumber, 'Delivered');
    }
    setToastMessage(`Order #${orderNumber} marked as delivered`);
    setTimeout(() => setToastMessage(''), 3000);
  };

  return (
    <PolarisPage
      title="Quick Delivery"
      subtitle="Quickly hand over ready orders and update delivery records"
      badge={
        <PolarisBadge tone={currentList.length > 0 ? 'warning' : 'success'}>
          {currentList.length} Pending
        </PolarisBadge>
      }
      backAction={() => onNavigate('orders')}
    >
      <div className="space-y-5">
        {/* Toast message */}
        {toastMessage && (
          <div className="p-3 bg-[#EAFBE7] border border-[#BBE5B3] text-[#108043] text-xs font-semibold rounded-lg flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4 text-[#108043]" />
              <span>{toastMessage}</span>
            </div>
            <button onClick={() => setToastMessage('')} className="text-[#108043] hover:opacity-75">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <PolarisCard flush>
          {/* Tabs & Search Header */}
          <div className="border-b border-[#E3E3E3]">
            <PolarisTabs<'Officer' | 'Airman'>
              tabs={[
                { id: 'Officer', label: 'Officer Orders', count: undeliveredOfficerOrders.length },
                { id: 'Airman', label: 'Airman Orders', count: undeliveredAirmanOrders.length },
              ]}
              selectedTab={activeTab}
              onSelectTab={(id: 'Officer' | 'Airman') => setActiveTab(id)}
            />
          </div>

          <div className="p-3 border-b border-[#E3E3E3] bg-[#FAFBFB] flex items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#616161]" />
              <input
                type="text"
                placeholder="Search by order #, BD number, customer name, or phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-md text-[#303030] focus:outline-none focus:border-[#303030]"
              />
            </div>
            <div className="text-xs text-[#616161] font-medium">
              Showing {filteredOrders.length} order{filteredOrders.length === 1 ? '' : 's'}
            </div>
          </div>

          {/* Table */}
          {filteredOrders.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-[#E3E3E3] bg-[#FAFBFB] text-[#616161] font-semibold h-[37px]">
                    <th className="px-4 py-2 w-24">Order #</th>
                    <th className="px-4 py-2 w-28">BD Number</th>
                    <th className="px-4 py-2">Customer</th>
                    <th className="px-4 py-2">Details / Items</th>
                    <th className="px-4 py-2 w-32">Delivery Due</th>
                    <th className="px-4 py-2 w-28">Status</th>
                    {activeTab === 'Officer' && <th className="px-4 py-2 text-right w-24">Due</th>}
                    <th className="px-4 py-2 text-right w-36">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E3E3E3]">
                  {filteredOrders.map((order: any) => {
                    const dueAmount = activeTab === 'Officer' ? Number(order.due) || 0 : 0;
                    return (
                      <tr
                        key={order.orderNumber}
                        className="h-[54px] hover:bg-[#F9FAFB] transition-colors"
                      >
                        <td className="px-4 py-2 font-semibold text-[#1A1A1A] tabular-nums">
                          #{order.orderNumber}
                        </td>
                        <td className="px-4 py-2 font-mono font-medium text-[#005BD3]">
                          {order.customerBdNumber}
                        </td>
                        <td className="px-4 py-2">
                          <div className="font-semibold text-[#1A1A1A]">{order.customerName}</div>
                          {order.customerPhone && (
                            <div className="text-[11px] text-[#616161] flex items-center space-x-1">
                              <Phone className="w-2.5 h-2.5 inline" />
                              <span>{order.customerPhone}</span>
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-2 text-[#4A4A4A]">
                          {activeTab === 'Officer' ? (
                            <span>
                              {order.items?.map((i: any) => `${i.name} ×${i.quantity}`).join(', ') || 'No items'}
                            </span>
                          ) : (
                            <div className="flex items-center space-x-2">
                              <span className="font-medium text-[#1A1A1A]">
                                {order.items?.map((i: any) => `${i.name} (${i.ivNumber || 'No IV'})`).join(', ')}
                              </span>
                              <span className="text-[11px] text-[#616161]">
                                • {order.runningYear}
                              </span>
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-2 text-[#4A4A4A] tabular-nums">
                          {order.deliveryDate || 'Not set'}
                        </td>
                        <td className="px-4 py-2">
                          <PolarisBadge
                            tone={
                              order.status === 'Ready'
                                ? 'success'
                                : order.status === 'Processing'
                                ? 'info'
                                : 'neutral'
                            }
                          >
                            {order.status}
                          </PolarisBadge>
                        </td>
                        {activeTab === 'Officer' && (
                          <td className="px-4 py-2 text-right font-semibold tabular-nums">
                            {dueAmount > 0 ? (
                              <span className="text-[#8E0B21]">৳{dueAmount}</span>
                            ) : (
                              <span className="text-[#0C5132]">Paid</span>
                            )}
                          </td>
                        )}
                        <td className="px-4 py-2 text-right">
                          <button
                            type="button"
                            onClick={() => handleDeliver(order.orderNumber)}
                            className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-[#303030] hover:bg-[#1A1A1A] text-white text-xs font-semibold rounded-md shadow-xs transition-colors"
                          >
                            <Truck className="w-3.5 h-3.5" />
                            <span>Mark Delivered</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="py-12 text-center text-[#616161] text-xs">
              <Truck className="w-8 h-8 mx-auto mb-2 text-[#616161] opacity-50" />
              <p className="font-medium">No pending {activeTab} deliveries</p>
              <p className="mt-1">All {activeTab.toLowerCase()} orders have been delivered or match no search results.</p>
            </div>
          )}
        </PolarisCard>
      </div>
    </PolarisPage>
  );
};
